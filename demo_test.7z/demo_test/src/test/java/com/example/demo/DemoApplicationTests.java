package com.example.demo;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.example.demo.entity.AreaDO;
import com.example.demo.entity.OrderDO;
import com.example.demo.entity.SkuAreaDO;
import com.example.demo.entity.SkuDO;
import com.example.demo.mapper.AreaMapper;
import com.example.demo.mapper.OrderMapper;
import com.example.demo.mapper.SkuAreaMapper;
import com.example.demo.mapper.SkuMapper;
import com.example.demo.model.Dto.request.order.ConfirmInfoDto;
import com.example.demo.model.Dto.request.order.CreateInfoDto;
import com.example.demo.model.Dto.request.order.CreateItemInfoDto;
import com.example.demo.model.Dto.response.logistics.FreightResultDto;
import com.example.demo.model.Dto.response.order.ConfirmResultDto;
import com.example.demo.model.Dto.response.order.CreateResultDto;
import com.example.demo.service.*;
import com.example.demo.util.OrderUtil;
import com.example.demo.util.Util;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest
public class DemoApplicationTests {
    @Autowired
    private ProductService productService;
    @Autowired
    private AreaService areaService;
    @Autowired
    private OrderService orderService;
    @Autowired
    private LogisticsService logisticsService;
    @Resource
    private SkuMapper skuMapper;
    @Resource
    private SkuAreaMapper skuAreaMapper;
    @Resource
    private AreaMapper areaMapper;
    @Resource
    private OrderMapper orderMapper;

    //===========================================[商品]=============================================
    @Test
    public void fetchArea() {
        areaService.get();
    }


    //todo 本来生活的商品大中小类也会改变，而商品的id是根据类别id来获取的，所以要改的话，改的记录很多，牵扯面广
    //todo 怎么搞？

    /**
     * 获取商品大类
     */
    @Test
    public void fetchCategoryOne() {
        productService.syncCatetoryOne();
    }

    /**
     * 获取商品中类
     */
    @Test
    public void fetchCategoryTwo() {
        productService.syncCatetoryTwo();
    }

    /**
     * 获取商品小类
     */
    @Test
    public void fetchCategoryThree() {
        productService.syncCatetoryThree();
    }

    /**
     * 获取商品标识
     */
    @Test
    public void fetchProductIds() {
        productService.syncProductIds();
    }

    /**
     * 获取商品主要信息
     */
    @Test
    public void fetchProductInfo() {
        productService.syncProductMainInfo();
    }

    /**
     * 获取商品主图
     */
    @Test
    public void fetchProductMainImgs() {
        productService.syncProductMainImages();
    }

    /**
     * 获取商品详情
     */
    @Test
    public void fetchProductDetail() {
        productService.syncProductDetail();
    }


    //todo 商品上下架状态是否影响商品主要信息商品主图的获取

    /**
     * 获取商品上下架状态
     */
    @Test
    public void fetchProductOnlineStatus() {
        productService.syncProductOnlineStatus();
    }

    //todo 商品下架的话，商品的可配送区域也是都查不到的吗？

    /**
     * 获取商品的可配送区域
     */
    @Test
    public void fetchProductCanDeliveryArea() {
        productService.syncProductCanDeliverArea();
    }

    /**
     * 获取商品的可销售区域
     */
    @Test
    public void fetchProductCanSaleArea() {
        productService.syncProductCanSaleArea();
    }

    /**
     * 获取商品的价格，分页
     */
    @Test
    public void fetchProductPrices() {
        productService.syncProductPrices();
    }

    /**
     * 获取商品的库存，分页
     */
    @Test
    public void fetchProductStocks() {
        productService.syncProductStocks();
    }
    //===========================================[订单]=============================================

    /**
     * 订单创建+订单确认
     */
    @Test
    public void createOrder() {
        //todo 与本来生活接口交互，创建订单，方法上要加事务，如果失败，因为有过期时间，怎么重试？
        CreateInfoDto createInfoDto = new CreateInfoDto();
        //上次生成的订单号：2270980482256
        String orderNo = OrderUtil.makeOrderNo();

        //判断是否达到免邮金额
        SkuDO skuDO = this.skuMapper.selectOne(new QueryWrapper<SkuDO>().lambda().eq(SkuDO::getId, 4299));
        String skuId = skuDO.getSkuId();
        //todo 商品可配送区域要用定时任务去同步
        //查询商品可送达区域
        //todo 如果一个订单存在多个商品，而每个商品的可配送区域是不同的，本来的流程是先选配送区域，然后再选可以购买的商品
        //todo 为什么要这样设计？
        List<SkuAreaDO> skuAreaDOS = this.skuAreaMapper.selectList(new QueryWrapper<SkuAreaDO>().lambda().eq(SkuAreaDO::getSkuId, skuId));
        SkuAreaDO skuAreaDO = skuAreaDOS.get(0);
        Integer provinceId = skuAreaDO.getProvinceId();
        Integer cityId = skuAreaDO.getCityId();
        Integer districtId = skuAreaDO.getDistrictId();
        String provinceName = this.areaMapper.selectOne(new QueryWrapper<AreaDO>().lambda().eq(AreaDO::getAreaId, provinceId)).getAreaName();
        String cityName = this.areaMapper.selectOne(new QueryWrapper<AreaDO>().lambda().eq(AreaDO::getAreaId, cityId)).getAreaName();
        String districtName = this.areaMapper.selectOne(new QueryWrapper<AreaDO>().lambda().eq(AreaDO::getAreaId, districtId)).getAreaName();
        //订单主信息
        createInfoDto.setOutTradeNo(orderNo);
        createInfoDto.setReceiveContact("小张");
        createInfoDto.setReceivePhone("12345678901");
        createInfoDto.setProvince(provinceName);
        createInfoDto.setCity(cityName);
        createInfoDto.setCounty(districtName);
        createInfoDto.setReceivePddress(provinceName + cityName + districtName);
        //根据省市区查询运费
        FreightResultDto freight = logisticsService.getFreight(provinceName, cityName, districtName);
        //此地区运费
        BigDecimal freight1 = freight.getFreight();
        //免邮金额
        BigDecimal freeAmount = freight.getFreeAmount();
        //暂时设置成一个测试商品的金额
        BigDecimal orderPrice = skuDO.getPrice();
        createInfoDto.setOrderPrice(orderPrice);
        //订单金额
        if (orderPrice.compareTo(freeAmount) == 1) {
            createInfoDto.setShipPrice(new BigDecimal("0.00"));
        } else {
            createInfoDto.setShipPrice(freight1);
        }
        //订单详情
        List<CreateItemInfoDto> itemList = new LinkedList<>();
        //查询商品
        CreateItemInfoDto orderDetailDto = new CreateItemInfoDto();
        orderDetailDto.setProductId(skuId);
        String productName = skuDO.getProductName();
        orderDetailDto.setProductName(productName);
        BigDecimal price = skuDO.getPrice();
        orderDetailDto.setPrice(price);
        orderDetailDto.setQuantity(1);
        itemList.add(orderDetailDto);
        createInfoDto.setOrderDetail(itemList);
        //todo 订单推送成功，更新运费到平台，这个运费是查询得到的
        CreateResultDto order = orderService.createOrder(createInfoDto);
        //预订单号
        String tradeNo = order.getTradeNo();
        //过期时间，可能是锁库时间
        Long expire = order.getExpire();

        //处理过期时间
        //todo 看业务流程，订单创建成功之后，有过期时间，在过期时间之前要把订单确认了
        //创单时间，格式， “yyyyMMddHHmmss”
        String createDateStr = order.getCreateDate();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        //todo 要以回传的时间为准，创建订单生成时间
        //此处逻辑是：数据库字段是localdatetime，然后时间工具类中加时间加秒数计算时间的入参要求是date类型
        //所以把时间格式的字符串先转换成date类型，然后计算，后再转换成字符串后再转换成localdatetime类型
        //todo LocalDateTime.now().minusDays()有类似的方法，可以不用这么麻烦，来回转
        Date createDate = null;
        try {
            createDate = sdf.parse(createDateStr);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
        LocalDateTime placetime = LocalDateTime.parse(createDateStr, df);
        Calendar now = Calendar.getInstance();
        now.setTime(createDate);
        //此方法是正常calendar类的复制方法
        Calendar now1 = (Calendar) now.clone();
        Date expiredDateTime = Util.addSomeSeconds(now, expire.intValue()).getTime();
        String expiredDateTimeStr = sdf.format(expiredDateTime);
        LocalDateTime expiredLocalDateTime = LocalDateTime.parse(expiredDateTimeStr, df);
        //插入订单表
        OrderDO orderDO = new OrderDO();
        orderDO.setOrderNo(orderNo);
        //外部订单号
        orderDO.setOutTradeNo(tradeNo);
        orderDO.setPlacedTime(placetime);
        orderDO.setExpiredTime(expiredLocalDateTime);
        this.orderMapper.insert(orderDO);

        //订单确认
        ConfirmInfoDto confirm = new ConfirmInfoDto();
        confirm.setTradeNo(tradeNo);
        ConfirmResultDto confirmResultDto = orderService.confirmOrder(confirm);
        //订单确认成功后，更新订单信息,获取到外部订单号
        String outTradeNo = confirmResultDto.getOutTradeNo();
        String orderId = confirmResultDto.getOrderId();
        OrderDO orderDO1 = new OrderDO();
        orderDO1.setOutOrderId(orderId);
        this.orderMapper.update(orderDO1, new QueryWrapper<OrderDO>().lambda().eq(OrderDO::getOrderNo, outTradeNo));
    }

}

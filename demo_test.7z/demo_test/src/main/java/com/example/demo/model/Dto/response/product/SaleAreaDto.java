package com.example.demo.model.Dto.response.product;

public class SaleAreaDto {
    private String productId ;
    private String isSales ;

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getIsSales() {
        return isSales;
    }

    public void setIsSales(String isSales) {
        this.isSales = isSales;
    }
}

package com.example.demo.model.configEnum;

public enum  UrlConfigEnum {

    //编码UTF-8
    ENCODEING_UTF8("UTF-8"),
    //超时时间
    CONNECTTIME(20000),
    //get请求
    METHODGET("GET"),
    //post请求
    METHODPOST("POST");

    private  String value;
    private  int val;

     UrlConfigEnum(String value) {
        this.value = value;
    }

    UrlConfigEnum(int val) {
        this.val = val;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public int getVal() {
        return val;
    }

    public void setVal(int val) {
        this.val = val;
    }
}

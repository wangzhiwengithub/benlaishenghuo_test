package com.example.demo.util;

import com.alibaba.fastjson.JSON;
import org.apache.commons.lang3.time.DateFormatUtils;

import java.net.URLEncoder;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;

public class Util {

    public static void main(String[] args) {

        String atcion = "/api/sss";
        String atcion1 = "api1/sss1";
        String a[] = atcion.split("/");
        String a1[] = atcion1.split("/");
        System.out.println(a);
        System.out.println(a1);
        Util.formartTime("Wed, 17 Apr 2019 13:33:23 GMT");
    }

    public static Date formartTime(String time) {
        time = time.replace(",", "");
        String[] timeStrings = time.split(" ");
        switch (timeStrings[2]) {
            case "Jan":
                timeStrings[2] = "01";
                break;
            case "Feb":
                timeStrings[2] = "02";
                break;
            case "Mar":
                timeStrings[2] = "03";
                break;
            case "Apr":
                timeStrings[2] = "04";
                break;
            case "May":
                timeStrings[2] = "05";
                break;
            case "Jun":
                timeStrings[2] = "06";
                break;
            case "Jul":
                timeStrings[2] = "07";
                break;
            case "Aug":
                timeStrings[2] = "08";
                break;
            case "Sep":
                timeStrings[2] = "09";
                break;
            case "Oct":
                timeStrings[2] = "10";
                break;
            case "Nov":
                timeStrings[2] = "11";
                break;
            case "Dec":
                timeStrings[2] = "12";
                break;
        }
        // String time1="Wed, 17 Apr 2019 12:33:23 GMT";
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        String date = timeStrings[3] + "-" + timeStrings[2] + "-" + timeStrings[1] + " " + timeStrings[4];
        Date datetime = null;
        try {
            datetime = df.parse(date);
            System.out.println(datetime);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return datetime;
    }

    public static String parseDictionaryToQueryString(Map<String, Object> query) {
        StringBuilder sb = new StringBuilder();
        if (query == null) return sb.toString();

        for (Map.Entry pair : query.entrySet()) {
            String json;
            String s = null;
            if (pair.getValue() instanceof String) {
                s = String.valueOf(pair.getValue());
            }
            if (s != null) json = s;
            else if (pair.getValue() instanceof Date) {
                json = DateFormatUtils.ISO_8601_EXTENDED_DATETIME_FORMAT.format(pair.getValue());
            } else {
                json = JSON.toJSONString(pair.getValue());
            }
            try {
                json = URLEncoder.encode(json, "UTF-8");
            } catch (Exception ignored) {
            }
            sb.append(pair.getKey()).append("=").append(json).append("&");
        }
        if (sb.length() > 0)
            sb.delete(sb.length() - 1, sb.length());
        return sb.toString();
    }

    public static double calTime(Date start, Date end) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(start);
        long timeStart = cal.getTimeInMillis();
        cal.setTime(end);
        long timeEnd = cal.getTimeInMillis();
        long dd = timeEnd - timeStart;
        double days = 1000 * 3600 * 24;
        System.out.println(dd / (1000.00 * 3600.00 * 24.00));
        return dd / days;
    }

    //过期时间相关计算，加上指定的秒数
    public static Calendar addSomeSeconds(Calendar calendar, int seconds) {
        calendar.add(Calendar.SECOND, seconds);
        return calendar;
    }
}

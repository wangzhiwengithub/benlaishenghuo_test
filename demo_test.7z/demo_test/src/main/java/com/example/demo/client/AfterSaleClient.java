package com.example.demo.client;


import com.example.demo.model.Dto.request.aftersale.*;


import com.example.demo.model.Dto.response.BaseResponseDto;

import com.example.demo.model.Dto.response.aftersale.*;



import com.example.demo.model.configEnum.UrlEnum;
import org.springframework.stereotype.Component;

import java.util.LinkedHashMap;
import java.util.Map;

@Component
public class AfterSaleClient extends BenLaiBaseClient{

    public BaseResponseDto<CreateResultDto> create (CreateInfoDto info){
        return   post( UrlEnum.AFTERSALECREATE.getUrl(),info,CreateResultDto.class);
    }
    public BaseResponseDto<AvailableResultDto> available(String doId) {
        Map<String, Object> params = new LinkedHashMap<>();
        params.put("do_id", doId);
        return get(UrlEnum.AFTERSALEAVAILABLE.getUrl(), params, AvailableResultDto.class);
    }

    public  BaseResponseDto<GetListResultDto>  list(String doId){
        Map<String, Object> params = new LinkedHashMap<>();
        params.put("do_id", doId);
        return get(UrlEnum.AFTERSALELIST.getUrl(), params, GetListResultDto.class);
    }

    public  BaseResponseDto<GetRMAResultDto>  get(String rmaId){
        Map<String, Object> params = new LinkedHashMap<>();
        params.put("rma_id", rmaId);
        return get(UrlEnum.AFTERSALEGET.getUrl(), params, GetRMAResultDto.class);
    }

    public BaseResponseDto<CancelResultDto> cancel (CancelInfoDto info){
        return   post( UrlEnum.AFTERSALECANCEL.getUrl(),info,CancelResultDto.class);
    }

}

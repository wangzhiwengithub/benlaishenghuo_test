package com.example.demo.service;


import com.example.demo.model.Dto.response.aftersale.*;
import com.example.demo.model.Dto.request.aftersale.*;

public interface AfterSaleService {

    CreateResultDto create(CreateInfoDto info);

    AvailableResultDto available(String doID);

    GetListResultDto list(String doID);

    GetRMAResultDto get(String rmaID);

    CancelResultDto cancel(CancelInfoDto info);

}

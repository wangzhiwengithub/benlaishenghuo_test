package com.example.demo.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.example.demo.client.ProductClient;
import com.example.demo.entity.*;
import com.example.demo.mapper.*;
import com.example.demo.model.Dto.response.invoice.InventoryDto;
import com.example.demo.model.Dto.response.invoice.InventoryResult;
import com.example.demo.model.Dto.response.product.*;
import com.example.demo.service.CategoryService;
import com.example.demo.service.ProductService;
import com.example.demo.util.GenericAndJson;
import com.example.demo.util.Page;
import com.example.demo.util.PageUtil;
import com.example.demo.vo.PageResponseVO;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Service("productService")
@Slf4j
public class ProductServiceImpl implements ProductService {
    @Autowired
    private CategoryService categoryService;
    @Autowired
    private ProductClient productClient;
    @Resource
    private CategoryMapper categoryMapper;
    @Resource
    private SkuMapper skuMapper;
    @Resource
    private SkuImgMapper skuImgMapper;
    @Resource
    private SkuDetailMapper skuDetailMapper;
    @Resource
    private SkuDetailImgMapper skuDetailImgMapper;
    @Resource
    private SkuAreaMapper skuAreaMapper;

    @Override
    public IdsResult ids(Integer categoryId) {
        IdsResult value = null;
        try {
            value = productClient.ids(categoryId).getValue();
        } catch (Exception e) {
            log.info(e.toString());
        }
        return value;
    }

    @Override
    public ProductResult item(String productIds) {
        return productClient.item(productIds).getValue();
    }

    @Override
    public ProductImageResult images(String productId) {
        return productClient.images(productId).getValue();
    }

    @Override
    public ProductDetailResult details(String productId) {
        return productClient.details(productId).getValue();
    }

    @Override
    public InventoryResult inventory(String productIds) {
        return productClient.inventory(productIds).getValue();
    }

    @Override
    public ProductCanDeliveryResult delivery(String productId) {
        return productClient.delivery(productId).getValue();
    }

    @Override
    public UpdownstatusResult updownstatus(String productIds) {
        return productClient.updownstatus(productIds).getValue();
    }

    @Override
    public CheckareaResult checkarea(String productIds, String province, String city, String area) {
        return productClient.checkarea(productIds, province, city, area).getValue();
    }

//    @Override
//    public CheckareaResult checkarea(String productIds) {
//        return productClient.checkarea(productIds).getValue();
//    }


    @Override
    public GetPriceResult getprice(String productIds) {
        return productClient.getprice(productIds).getValue();
    }

    @Override
    public void syncProductIds() {
        //todo 重新导入商品，看为什么有的categoryid会报空指针异常，原因1：超时
        QueryWrapper<CategoryDO> wrapper = new QueryWrapper<>();
        wrapper.lambda().eq(CategoryDO::getLevel, 3);
        List<CategoryDO> categoryDOS = categoryMapper.selectList(wrapper);
        for (CategoryDO categoryDO : categoryDOS) {
            Integer categoryId = categoryDO.getCategoryId();
            log.info("类别id:=={}", categoryId);
            IdsResult ids = null;
            try {
                ids = this.ids(categoryId);
            } catch (Exception e) {
                log.info("异常信息=={}", e.toString());
            }
            if (ids == null) {
                log.info("获取到类别id=={}==的商品id集合为null", categoryId);
                continue;
            }
            List<String> productIds = null;
            try {
                productIds = ids.getProductIds();
                log.info("获取到类别id=={}==的商品id集合", categoryId);
            } catch (Exception e) {
                log.info("类别id:=={}的商品id集合获取失败", categoryId);
                e.printStackTrace();
            }
            if (productIds == null) {
                continue;
            }
            for (String productId : productIds) {
                //检测数据
                log.info("查询商品编码：{}的商品====是否已经导入", productId);
                SkuDO skuDoSelect = this.skuMapper.selectOne(new QueryWrapper<SkuDO>().lambda().eq(SkuDO::getSkuId, productId));
                if (skuDoSelect == null) {
                    //插入数据
                    log.info("查询商品编码：{}的商品====没有导入过", productId);
                    SkuDO skuDO = new SkuDO();
                    skuDO.setSkuId(productId);
                    skuDO.setCategoryId(categoryDO.getCategoryId());
                    this.skuMapper.insert(skuDO);
                    log.info("导入商品编码：{}的商品", productId);
                }
            }
        }
    }

    @Override
    public void syncProductMainInfo() {
        //todo 主表初始和明细，对应多个表，将状态更改为明细，之前，把相关操作，都完成了，再更改标志位
        //todo 即方法需要组装
        //查询商品标识
        List<SkuDO> skuDOS = this.skuMapper.selectList(new QueryWrapper<SkuDO>().lambda().eq(SkuDO::getStatus, 0));
        int size = skuDOS.size();
        //分页参数
        int page = 0;
        int count = 30;
        if (size % count == 0) {
            page = size / count;
        } else {
            page = size / count + 1;
        }
        //分页查询
        for (int i = 0; i < page; i++) {
            System.out.println(i);
            //todo 自定义pager对象没有生效
            Page<SkuDO> pager = new Page<>(i, count);
            IPage<SkuDO> paging = this.skuMapper.selectPage(pager, new QueryWrapper<SkuDO>().lambda().eq(SkuDO::getStatus, 0));
//            PageResponseVO<SkuDO> res = PageUtil.build(paging);
//            List<SkuDO> items = res.getItems();
            List<String> skuIds = paging.getRecords().stream().map(skuDO -> skuDO.getSkuId()).collect(Collectors.toList());
            //传入商品标识，调用接口（集合）
            JSONArray jsonArray = new JSONArray();
            jsonArray.addAll(skuIds);
            String idParams = JSON.toJSONString(jsonArray);
            ProductResult item = null;
            try {
                item = this.item(idParams);
                String subCode = item.getSubCode();
                String subMsg = item.getSubMsg();
                log.info("调用本来生活主信息接口响应码=={},响应信息=={}", subCode, subMsg);
            } catch (Exception e) {
                e.printStackTrace();
                log.info("调用本来生活商品主信息接口异常，异常原因=={}", e.toString());
            }
            List<ProductInfo> productList = null;
            try {
                productList = item.getProductList();
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (productList == null) {
                continue;
            }
            for (ProductInfo productInfo : productList) {
                String skuId = productInfo.getProductId();
                SkuDO skuDO1 = new SkuDO();
                skuDO1.setSkuId(skuId);
                skuDO1.setProductName(productInfo.getProductName());
                skuDO1.setC1Id(productInfo.getC1Id());
                skuDO1.setC1Name(productInfo.getC1Name());
                skuDO1.setC2Id(productInfo.getC2id());
                skuDO1.setC2Name(productInfo.getC2Name());
                skuDO1.setC3Id(productInfo.getC3id());
                skuDO1.setC3Name(productInfo.getC3Name());
                skuDO1.setVendor(productInfo.getVendor());
                skuDO1.setPrice(productInfo.getPrice());
                skuDO1.setProductionArea(productInfo.getProductionArea());
                //更新商品信息（单个）
                int update = this.skuMapper.update(skuDO1, new QueryWrapper<SkuDO>().lambda().eq(SkuDO::getSkuId, skuId));
                if (update > 0) {
                    SkuDO skuDO2 = new SkuDO();
                    skuDO2.setSkuId(skuId);
                    skuDO2.setStatus(1);
                    this.skuMapper.update(skuDO2, new QueryWrapper<SkuDO>().lambda().eq(SkuDO::getSkuId, skuId));
                    log.info("更新完商品编码为=={}==的商品主信息", skuId);
                }
            }
        }
    }

    @Override
    public void syncProductMainImages() {
        List<SkuDO> skuDOS = this.skuMapper.selectList(new QueryWrapper<SkuDO>().lambda().eq(SkuDO::getStatus, 0));
        for (SkuDO skuDO : skuDOS) {
            String skuId = skuDO.getSkuId();
            //TODO 接口会报超时错误，没有获取怎么把这个记录，记录下来，以便再次获取
            ProductImageResult images = null;
            try {
                images = this.images(skuId);
                log.info("商品编码为=={}的商品获取主图返回响应码=={}，响应信息=={}", images.getSubCode(), images.getSubMsg());
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (images == null) {
                continue;
            }
            List<ProductImageDto> imagesInfo = null;
            try {
                imagesInfo = images.getImages();
            } catch (Exception e) {
                e.printStackTrace();
                log.error(e.toString());
            }
            if (imagesInfo == null) {
                continue;
            }
            for (ProductImageDto productImageDto : imagesInfo) {
                SkuImgDO skuImgDO = new SkuImgDO();
                skuImgDO.setSkuId(skuId);
                skuImgDO.setIsPrimary(productImageDto.getIsPrimary());
                skuImgDO.setSort(productImageDto.getSort());
                skuImgDO.setBenlaiImg(productImageDto.getImgUrl());
                this.skuImgMapper.insert(skuImgDO);
            }

        }

    }

    @Override
    public void syncProductDetail() {
        List<SkuDO> skuDOS = this.skuMapper.selectList(new QueryWrapper<SkuDO>().lambda().eq(SkuDO::getStatus, 1));
        for (SkuDO skuDO : skuDOS) {
            String skuId = skuDO.getSkuId();
            ProductDetailResult details = null;
            try {
                //todo details方法存在超时，就是获取不到的现象
                details = this.details(skuId);
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (details == null) {
                continue;
            }
            //昵称
            String nickName = details.getNickName();
            //规格
            String model = details.getModel();
            //尺寸
            String size = details.getSize();
            //保质期
            String productionDate = details.getProductionDate();
            //存储方式
            String storage = details.getStorage();
            SkuDetailDO skuDetailDO = new SkuDetailDO();
            skuDetailDO.setSkuId(skuId);
            skuDetailDO.setNickName(nickName);
            skuDetailDO.setModel(model);
            skuDetailDO.setSize(size);
            skuDetailDO.setProductionDate(productionDate);
            skuDetailDO.setStorage(storage);
            this.skuDetailMapper.insert(skuDetailDO);
            Integer id = skuDetailDO.getId();
            //features，1：n(detailitem)
            List<DetailItemResult> features = details.getFeatures();
            if (features == null) {
                continue;
            }
            for (DetailItemResult item : features) {
                String content = item.getContent();
                String imgUrl = item.getImgUrl();
                SkuDetailImgDO skuDetailImgDO = new SkuDetailImgDO();
                skuDetailImgDO.setSkuDetailId(id);
                skuDetailImgDO.setContent(content);
                skuDetailImgDO.setBenlaiDetailimg(imgUrl);
//                if (StringUtils.isNotBlank(content)) {
//                    System.out.println(content);
//                    skuDetailImgDO.setIndex(Integer.valueOf(content.substring(content.length() - 1)));
//                }
                this.skuDetailImgMapper.insert(skuDetailImgDO);
            }
            //buyers,1:n(detailitem)
            List<DetailItemResult> buyers = details.getBuyers();
            if (buyers == null) {
                continue;
            }
            for (DetailItemResult item : features) {
                String content = item.getContent();
                String imgUrl = item.getImgUrl();
                SkuDetailImgDO skuDetailImgDO = new SkuDetailImgDO();
                skuDetailImgDO.setSkuDetailId(id);
                skuDetailImgDO.setContent(content);
                skuDetailImgDO.setBenlaiDetailimg(imgUrl);
//                if (StringUtils.isNotBlank(content)) {
//                    System.out.println(content);
//                    skuDetailImgDO.setIndex(Integer.valueOf(content.substring(content.length() - 1)));
//                }
                this.skuDetailImgMapper.insert(skuDetailImgDO);
            }
            //proposals,1:n(detailitem)
            List<DetailItemResult> proposals = details.getProposals();
            if (proposals == null) {
                continue;
            }
            for (DetailItemResult item : features) {
                String content = item.getContent();
                String imgUrl = item.getImgUrl();
                SkuDetailImgDO skuDetailImgDO = new SkuDetailImgDO();
                skuDetailImgDO.setSkuDetailId(id);
                skuDetailImgDO.setContent(content);
                skuDetailImgDO.setBenlaiDetailimg(imgUrl);
//                if (StringUtils.isNotBlank(content)) {
//                    System.out.println(content);
//                    skuDetailImgDO.setIndex(Integer.valueOf(content.substring(content.length() - 1)));
//                }
                this.skuDetailImgMapper.insert(skuDetailImgDO);
            }
            //stories,1:n(detailitem)
            List<DetailItemResult> stories = details.getStories();
            if (stories == null) {
                continue;
            }
            for (DetailItemResult item : features) {
                String content = item.getContent();
                String imgUrl = item.getImgUrl();
                SkuDetailImgDO skuDetailImgDO = new SkuDetailImgDO();
                skuDetailImgDO.setSkuDetailId(id);
                skuDetailImgDO.setContent(content);
                skuDetailImgDO.setBenlaiDetailimg(imgUrl);
//                if (StringUtils.isNotBlank(content)) {
//                    System.out.println(content);
//                    skuDetailImgDO.setIndex(Integer.valueOf(content.substring(content.length() - 1)));
//                }
                this.skuDetailImgMapper.insert(skuDetailImgDO);
            }
            //steps,1:n(detailstep)
//            List<DetailStepResult> steps = details.getSteps();
//            if (features == null){
//                continue;
//            }
        }
    }

    @Override
    public void syncProductOnlineStatus() {
        //todo 这个查询数量其他使用到的地方要替换
        Integer size = this.skuMapper.selectCount(new QueryWrapper<SkuDO>().lambda().eq(SkuDO::getStatus, 0));
        //分页参数
        int page = 0;
        int count = 30;
        if (size % count == 0) {
            page = size / count;
        } else {
            page = size / count + 1;
        }
        //分页查询
        for (int i = 0; i < page; i++) {
            System.out.println(i);
            //todo 自定义pager对象没有生效
            Page<SkuDO> pager = new Page<>(i, count);
            IPage<SkuDO> paging = this.skuMapper.selectPage(pager, new QueryWrapper<SkuDO>().lambda().eq(SkuDO::getStatus, 0));
//            PageResponseVO<SkuDO> res = PageUtil.build(paging);
//            List<SkuDO> items = res.getItems();
            List<String> skuIds = paging.getRecords().stream().map(skuDO -> skuDO.getSkuId()).collect(Collectors.toList());
            //传入商品标识，调用接口（集合）
            JSONArray jsonArray = new JSONArray();
            jsonArray.addAll(skuIds);
            String idParams = JSON.toJSONString(jsonArray);
            UpdownstatusResult updownstatus = null;
            try {
                updownstatus = this.updownstatus(idParams);
                log.info("批量获取商品的上下架状态的响应码=={},响应信息为=={}", updownstatus.getSubCode(), updownstatus.getSubMsg());
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (updownstatus == null) {
                log.info("批量获取商品的上下架状态的结果为null");
                continue;
            }
            List<PoductupdownstatusDto> details = updownstatus.getDetails();
            for (PoductupdownstatusDto item : details) {
                SkuDO skuDO = new SkuDO();
                String productId = item.getProductId();
                String updownstatusStr = item.getUpdownstatus();
                skuDO.setSkuId(productId);
                log.info("商品编码为=={}==的上下架状态为=={}", productId, updownstatusStr);
                //todo 商品上下架状态可以关联地区参数进行查询
                //todo 商品上下架状态的更新要添加日志
                if ("UP".equals(updownstatusStr)) {
                    skuDO.setOnline(1);
                }
                if ("DOWN".equals(updownstatusStr)) {
                    skuDO.setOnline(0);
                }
                int update = this.skuMapper.update(skuDO, new QueryWrapper<SkuDO>().lambda().eq(SkuDO::getSkuId, productId));
                if (update == 1) {
                    //todo 记录日志，记录变更前的状态和变更后的状态
                }
            }
        }
    }

    @Override
    public void syncProductCanDeliverArea() {
        //todo 判断商品的可配送区域是绝大多数还是少数，如果可以配送的区域比较多的话，反选
        //todo 表结构设计，类似于多规格，以逗号分隔，存入一个字段
        List<SkuDO> skuDOS = this.skuMapper.selectList(new QueryWrapper<SkuDO>().lambda().eq(SkuDO::getStatus, 0));
        for (SkuDO skuDO : skuDOS) {
            String skuId = skuDO.getSkuId();
//            JSONArray jsonArray = new JSONArray();
//            jsonArray.add(skuId);
//            String idParams = JSON.toJSONString(jsonArray);
            ProductCanDeliveryResult delivery = null;
            try {
                delivery = this.delivery(skuId);
            } catch (Exception e) {
                e.printStackTrace();
                continue;
            }
            List<DeliveryAreaDto> areaList = delivery.getAreaList();
            //TODO 获取到可以配送的区域，下一步怎么做？
            for (DeliveryAreaDto deliveryAreaDto : areaList) {
                Integer provinceId = deliveryAreaDto.getProvinceId();
                String provinceName = deliveryAreaDto.getProvinceName();
                Integer cityid = deliveryAreaDto.getCityid();
                String cityName = deliveryAreaDto.getCityName();
                Integer districtId = deliveryAreaDto.getDistrictId();
                String districtName = deliveryAreaDto.getDistrictName();
                SkuAreaDO skuAreaDO = new SkuAreaDO();
                skuAreaDO.setSkuId(skuId);
                skuAreaDO.setProvinceId(provinceId);
                skuAreaDO.setCityId(cityid);
                skuAreaDO.setDistrictId(districtId);
                this.skuAreaMapper.insert(skuAreaDO);
            }
        }

    }

    @Override
    public void syncProductCanSaleArea() {
        //todo 判断商品的可销售区域是绝大多数还是少数，如果可以配送的区域比较多的话，反选
        //todo 表结构设计，类似于多规格，以逗号分隔，存入一个字段
        List<SkuDO> skuDOS = this.skuMapper.selectList(new QueryWrapper<SkuDO>().lambda().eq(SkuDO::getStatus, 1));
        for (SkuDO skuDO : skuDOS) {
//            P0000004511
            String skuId = skuDO.getSkuId();
//            skuId = "P0000004511";
            JSONArray jsonArray = new JSONArray();
            jsonArray.add(skuId);
            String idParams = JSON.toJSONString(jsonArray);
            //todo 查询商品可售区域需要关联省市区参数
            CheckareaResult checkarea = this.checkarea(idParams, "上海市", "上海市", "黄浦区");
            List<SaleAreaDto> checkList = checkarea.getCheckList();
            for (SaleAreaDto saleAreaDto : checkList) {
                String productId = saleAreaDto.getProductId();
                String isSales = saleAreaDto.getIsSales();
                System.out.println(productId + "：" + isSales);
            }
        }

    }

    @Override
    public void syncProductPrices() {
        Integer size = this.skuMapper.selectCount(new QueryWrapper<SkuDO>().lambda().eq(SkuDO::getStatus, 1));
        //分页参数
        int page = 0;
        int count = 30;
        if (size % count == 0) {
            page = size / count;
        } else {
            page = size / count + 1;
        }
        //分页查询
        for (int i = 0; i < page; i++) {
            System.out.println(i);
            //todo 自定义pager对象没有生效
            Page<SkuDO> pager = new Page<>(i, count);
            IPage<SkuDO> paging = this.skuMapper.selectPage(pager, new QueryWrapper<SkuDO>().lambda().eq(SkuDO::getStatus, 1));
//            PageResponseVO<SkuDO> res = PageUtil.build(paging);
//            List<SkuDO> items = res.getItems();
            List<String> skuIds = paging.getRecords().stream().map(skuDO -> skuDO.getSkuId()).collect(Collectors.toList());
            //传入商品标识，调用接口（集合）
            JSONArray jsonArray = new JSONArray();
            jsonArray.addAll(skuIds);
            String idParams = JSON.toJSONString(jsonArray);
            GetPriceResult getprice = null;
            try {
                getprice = this.getprice(idParams);
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (getprice == null) {
                continue;
            }
            List<ProductPriceDto> priceList = getprice.getPriceList();
            for (ProductPriceDto productPriceDto : priceList) {
                String productId = productPriceDto.getProductId();
                BigDecimal price = productPriceDto.getPrice();
                BigDecimal marketPrice = productPriceDto.getMarketPrice();
                int tax = productPriceDto.getTax();
                SkuDO skuDO = new SkuDO();
                skuDO.setPrice(price);
                skuDO.setTax(tax);
                skuDO.setMarketPrice(marketPrice);
                int update = this.skuMapper.update(skuDO, new QueryWrapper<SkuDO>().lambda().eq(SkuDO::getSkuId, productId));
                if (update == 1) {
                    //todo 这些状态的变化需要添加日志
                }
            }

        }
    }

    @Override
    public void syncProductStocks() {
        Integer size = this.skuMapper.selectCount(new QueryWrapper<SkuDO>().lambda().eq(SkuDO::getStatus, 1));
        //分页参数
        int page = 0;
        int count = 30;
        if (size % count == 0) {
            page = size / count;
        } else {
            page = size / count + 1;
        }
        //分页查询
        for (int i = 0; i < page; i++) {
            System.out.println(i);
            //todo 自定义pager对象没有生效
            Page<SkuDO> pager = new Page<>(i, count);
            IPage<SkuDO> paging = this.skuMapper.selectPage(pager, new QueryWrapper<SkuDO>().lambda().eq(SkuDO::getStatus, 1));
            List<String> skuIds = paging.getRecords().stream().map(skuDO -> skuDO.getSkuId()).collect(Collectors.toList());
            //传入商品标识，调用接口（集合）
            JSONArray jsonArray = new JSONArray();
            jsonArray.addAll(skuIds);
            String idParams = JSON.toJSONString(jsonArray);
            //TODO 库存查询可以关联省市区参数
            InventoryResult inventory = null;
            try {
                inventory = this.inventory(idParams);
            } catch (Exception e) {
                e.printStackTrace();
            }
            List<InventoryDto> productList = inventory.getProductList();
            for (InventoryDto inventoryDto : productList) {
                String productId = inventoryDto.getProductId();
                int qty = inventoryDto.getQty();
                SkuDO skuDO = new SkuDO();
                skuDO.setStock(qty);
                int update = this.skuMapper.update(skuDO, new QueryWrapper<SkuDO>().lambda().eq(SkuDO::getSkuId, productId));
                if (update == 1) {
                    //todo 库存更新的变化可能需要添加日志
                }
            }
        }

    }

    @Override
    public void syncCatetoryOne() {
        this.categoryService.categoryOne();
    }

    @Override
    public void syncCatetoryTwo() {
        this.categoryService.categoryTwo();
    }

    @Override
    public void syncCatetoryThree() {
        this.categoryService.categoryThree();
    }

}

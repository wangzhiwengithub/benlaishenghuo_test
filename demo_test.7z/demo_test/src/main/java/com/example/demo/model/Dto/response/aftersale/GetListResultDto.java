package com.example.demo.model.Dto.response.aftersale;

import com.example.demo.model.Dto.response.ErrorResponseDto;

import java.util.List;

public class GetListResultDto extends ErrorResponseDto {
    private List<GetListRMAResult> rmaList;

    public List<GetListRMAResult> getRmaList() {
        return rmaList;
    }

    public void setRmaList(List<GetListRMAResult> rmaList) {
        this.rmaList = rmaList;
    }
}

package com.example.demo.model.Dto.response.createOrder;

import com.alibaba.fastjson.annotation.JSONField;
import com.example.demo.model.Dto.response.ErrorResponseDto;

public class CreateResultDto extends ErrorResponseDto {
        @JSONField(name = "trade_no")
        private String tradeNo;
        @JSONField(name = "create_date")
        public String createDate;
        private Long expire;




       public String getTradeNo() {
                return tradeNo;
        }

        public void setTradeNo(String tradeNo) {
                this.tradeNo = tradeNo;
        }

        public String getCreateDate() {
                return createDate;
        }

        public void setCreateDate(String createDate) {
                this.createDate = createDate;
        }

        public Long getExpire() {
                return expire;
        }

        public void setExpire(Long expire) {
                this.expire = expire;
        }
}

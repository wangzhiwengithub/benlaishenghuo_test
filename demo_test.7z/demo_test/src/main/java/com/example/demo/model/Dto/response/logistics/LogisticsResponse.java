package com.example.demo.model.Dto.response.logistics;

import java.util.List;

public class LogisticsResponse {

    public String doNo;
    public String waybillNo;
    public String phone;
    public String contact;
    public String shipTypeName;
    public String courierName;
    public String courierPhone;
    public List<LogisticsDetailResponse> detaillist;

    public String getDoNo() {
        return doNo;
    }

    public void setDoNo(String doNo) {
        this.doNo = doNo;
    }

    public String getWaybillNo() {
        return waybillNo;
    }

    public void setWaybillNo(String waybillNo) {
        this.waybillNo = waybillNo;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getShipTypeName() {
        return shipTypeName;
    }

    public void setShipTypeName(String shipTypeName) {
        this.shipTypeName = shipTypeName;
    }

    public String getCourierName() {
        return courierName;
    }

    public void setCourierName(String courierName) {
        this.courierName = courierName;
    }

    public String getCourierPhone() {
        return courierPhone;
    }

    public void setCourierPhone(String courierPhone) {
        this.courierPhone = courierPhone;
    }

    public List<LogisticsDetailResponse> getDetaillist() {
        return detaillist;
    }

    public void setDetaillist(List<LogisticsDetailResponse> detaillist) {
        this.detaillist = detaillist;
    }
}

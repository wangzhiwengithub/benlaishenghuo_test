package com.example.demo.model.Dto.request.order;

import com.alibaba.fastjson.annotation.JSONField;

public class CancelInfoDto {
    @JSONField(name = "out_trade_no")
    private String outTradeNo;

    public String getOutTradeNo() {
        return outTradeNo;
    }

    public void setOutTradeNo(String outTradeNo) {
        this.outTradeNo = outTradeNo;
    }
}

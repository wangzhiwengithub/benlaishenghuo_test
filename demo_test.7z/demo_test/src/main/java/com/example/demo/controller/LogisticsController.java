package com.example.demo.controller;

import com.example.demo.model.Dto.response.logistics.DoLogListResultDto;
import com.example.demo.model.Dto.response.logistics.FreightResultDto;
import com.example.demo.service.LogisticsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("open/logistics")
public class LogisticsController {
    @Autowired
    private LogisticsService logisticsService;

    @RequestMapping(value = "/get",method = RequestMethod.GET)
    @ResponseBody
    public DoLogListResultDto get(String outTradeNo){
        return  logisticsService.get(outTradeNo);
    }
    @RequestMapping(value = "/getfreight",method = RequestMethod.GET)
    @ResponseBody
    public FreightResultDto getfreight(String province,String city,String county){
        return logisticsService.getFreight(province,city,county);
    }
}

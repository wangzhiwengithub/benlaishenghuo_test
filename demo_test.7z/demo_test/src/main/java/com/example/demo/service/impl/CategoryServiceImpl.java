package com.example.demo.service.impl;

import com.example.demo.client.CategoryClient;
import com.example.demo.entity.CategoryDO;
import com.example.demo.mapper.CategoryMapper;
import com.example.demo.model.Dto.response.category.CategoryInfo;
import com.example.demo.model.Dto.response.category.CategoryResult;
import com.example.demo.service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service("categoryService")
public class CategoryServiceImpl implements CategoryService {
    @Autowired
    private CategoryClient categoryClient;
    @Resource
    private CategoryMapper categoryMapper;

    @Override
    public CategoryResult categoryOne() {
        List<CategoryInfo> categoryList = categoryClient.categoryOne().getValue().getCategoryList();
        //todo 查询是否已经插入过
        Integer count = this.categoryMapper.selectCount(null);
        if (count > 0) {
            return null;
        }
        this.insertCategory(categoryList);
        return categoryClient.categoryOne().getValue();
    }

    @Override
    public CategoryResult categoryTwo() {
        List<CategoryInfo> categoryList = categoryClient.categoryTwo().getValue().getCategoryList();
        //todo 查询是否已经插入过
        this.insertCategory(categoryList);
        return categoryClient.categoryTwo().getValue();
    }

    @Override
    public CategoryResult categoryThree() {
        List<CategoryInfo> categoryList = categoryClient.categoryThree().getValue().getCategoryList();
        //todo 查询是否已经插入过
        this.insertCategory(categoryList);
        return categoryClient.categoryThree().getValue();
    }

    private void insertCategory(List<CategoryInfo> categoryList) {
        for (CategoryInfo categoryInfo : categoryList) {
            categoryMapper.insert(CategoryDO.builder().categoryId(categoryInfo.getCategoryId())
                    .categoryName(categoryInfo.getCategoryName())
                    .parentId(categoryInfo.getParentId())
                    .level(categoryInfo.getLevel())
                    .build());
        }
    }
}

package com.example.demo.model.Dto.response.order;

import com.alibaba.fastjson.annotation.JSONField;
import com.example.demo.model.Dto.response.ErrorResponseDto;

import java.util.List;

public class QueryDoResultDto extends ErrorResponseDto {
//@JSONField(name="out_trade_no")
    private String outTradeNo;
    //@JSONField(name="order_id")
    private String orderId;
    //@JSONField(name="out_time")
    private String outTime;
    //@JSONField(name="do_status")
    private String doStatus;
    //@JSONField(name="do_status_remark")
    private String doStatusRemark;
    //@JSONField(name="ship_price")
    private String shipPrice;
    //@JSONField(name="waybill_no")
    private String waybillNo;
   // @JSONField(name="express_company")
    private String expressCompany;

    private List<DODetailDto> detail;

    public String getOutTradeNo() {
        return outTradeNo;
    }

    public void setOutTradeNo(String outTradeNo) {
        this.outTradeNo = outTradeNo;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getOutTime() {
        return outTime;
    }

    public void setOutTime(String outTime) {
        this.outTime = outTime;
    }

    public String getDoStatus() {
        return doStatus;
    }

    public void setDoStatus(String doStatus) {
        this.doStatus = doStatus;
    }

    public String getDoStatusRemark() {
        return doStatusRemark;
    }

    public void setDoStatusRemark(String doStatusRemark) {
        this.doStatusRemark = doStatusRemark;
    }

    public String getShipPrice() {
        return shipPrice;
    }

    public void setShipPrice(String shipPrice) {
        this.shipPrice = shipPrice;
    }

    public String getWaybillNo() {
        return waybillNo;
    }

    public void setWaybillNo(String waybillNo) {
        this.waybillNo = waybillNo;
    }

    public String getExpressCompany() {
        return expressCompany;
    }

    public void setExpressCompany(String expressCompany) {
        this.expressCompany = expressCompany;
    }

    public List<DODetailDto> getDetail() {
        return detail;
    }

    public void setDetail(List<DODetailDto> detail) {
        this.detail = detail;
    }
}

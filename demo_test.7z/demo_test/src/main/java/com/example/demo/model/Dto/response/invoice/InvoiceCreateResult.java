package com.example.demo.model.Dto.response.invoice;

import com.example.demo.model.Dto.response.ErrorResponseDto;

public class InvoiceCreateResult extends ErrorResponseDto {
    private  String invoiceId;

    public String getInvoiceId() {
        return invoiceId;
    }

    public void setInvoiceId(String invoiceId) {
        this.invoiceId = invoiceId;
    }
}

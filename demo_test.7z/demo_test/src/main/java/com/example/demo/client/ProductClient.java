package com.example.demo.client;

import com.example.demo.model.Dto.response.BaseResponseDto;
import com.example.demo.model.Dto.response.invoice.InventoryResult;
import com.example.demo.model.Dto.response.product.*;
import com.example.demo.model.configEnum.UrlEnum;
import org.springframework.stereotype.Component;

import java.util.LinkedHashMap;
import java.util.Map;

@Component
public class ProductClient extends BenLaiBaseClient {


    public BaseResponseDto<IdsResult> ids(int categoryId) {
        Map<String, Object> params = new LinkedHashMap<>();
        String s = String.valueOf(categoryId);
        params.put("category_id", s);
        return get(UrlEnum.PRODUCTIDS.getUrl(), params, IdsResult.class);
    }

    public BaseResponseDto<ProductResult> item(String productIds) {
        Map<String, Object> params = new LinkedHashMap<>();
        params.put("product_ids", productIds);
        return get(UrlEnum.PRODUCTITEM.getUrl(), params, ProductResult.class);
    }


    public BaseResponseDto<ProductImageResult> images(String productId) {
        Map<String, Object> params = new LinkedHashMap<>();
        params.put("product_id", productId);
        return get(UrlEnum.PRODUCTIMEGES.getUrl(), params, ProductImageResult.class);
    }

    public BaseResponseDto<ProductDetailResult> details(String productId) {
        Map<String, Object> params = new LinkedHashMap<>();
        params.put("product_id", productId);
        return get(UrlEnum.PRODUCTDETAILS.getUrl(), params, ProductDetailResult.class);
    }

    public BaseResponseDto<InventoryResult> inventory(String productIds) {
        Map<String, Object> params = new LinkedHashMap<>();
        params.put("product_ids", productIds);
        return get(UrlEnum.PRODUCTINVENTORY.getUrl(), params, InventoryResult.class);
    }

    public BaseResponseDto<ProductCanDeliveryResult> delivery(String productId) {
        Map<String, Object> params = new LinkedHashMap<>();
        params.put("product_id", productId);
        return get(UrlEnum.PRODUCTDELIVERYAREA.getUrl(), params, ProductCanDeliveryResult.class);
    }

    public BaseResponseDto<UpdownstatusResult> updownstatus(String productIds) {
        Map<String, Object> params = new LinkedHashMap<>();
        params.put("product_ids", productIds);
        return get(UrlEnum.PRODUCTUPDOWNSTATUS.getUrl(), params, UpdownstatusResult.class);
    }

    //    public BaseResponseDto<CheckareaResult> checkarea(String productIds) {
//        Map<String, Object> params = new LinkedHashMap<>();
//        params.put("product_ids", productIds);
//        return get(UrlEnum.PRODUCTCHECKAREA.getUrl(), params, CheckareaResult.class);
//    }
    public BaseResponseDto<CheckareaResult> checkarea(String productIds, String province, String city, String area) {
        Map<String, Object> params = new LinkedHashMap<>();
        params.put("product_ids", productIds);
        params.put("province", province);
        params.put("city", city);
        params.put("county", area);
        return get(UrlEnum.PRODUCTCHECKAREA.getUrl(), params, CheckareaResult.class);
    }


    public BaseResponseDto<GetPriceResult> getprice(String productIds) {
        Map<String, Object> params = new LinkedHashMap<>();
        params.put("product_ids", productIds);
        return get(UrlEnum.PRODUCTGETPRICE.getUrl(), params, GetPriceResult.class);
    }
}

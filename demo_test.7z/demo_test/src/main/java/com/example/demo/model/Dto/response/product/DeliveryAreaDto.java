package com.example.demo.model.Dto.response.product;

public class DeliveryAreaDto {
    //        {
//            "province_id":26,
//                "province_name":"上海市",
//                "city_id":120,
//                "city_name":"上海市",
//                "district_id":1092,
//                "district_name":"徐汇区"
//        }
    private Integer provinceId;
    private String provinceName;
    private Integer cityid;
    private String cityName;
    private Integer districtId;
    private String districtName;

    public Integer getProvinceId() {
        return provinceId;
    }

    public void setProvinceId(Integer provinceId) {
        this.provinceId = provinceId;
    }

    public String getProvinceName() {
        return provinceName;
    }

    public void setProvinceName(String provinceName) {
        this.provinceName = provinceName;
    }

    public Integer getCityid() {
        return cityid;
    }

    public void setCityid(Integer cityid) {
        this.cityid = cityid;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public Integer getDistrictId() {
        return districtId;
    }

    public void setDistrictId(Integer districtId) {
        this.districtId = districtId;
    }

    public String getDistrictName() {
        return districtName;
    }

    public void setDistrictName(String districtName) {
        this.districtName = districtName;
    }
}

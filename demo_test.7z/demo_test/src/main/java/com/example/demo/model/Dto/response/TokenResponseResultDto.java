package com.example.demo.model.Dto.response;

import com.alibaba.fastjson.annotation.JSONField;

public class TokenResponseResultDto {
    @JSONField( name="access_token")
    private  String accessToken;
    @JSONField( name="token_type")
    private  String tokenType;
    @JSONField( name="expires_in")
    private  String expiresIn;
    @JSONField( name="refresh_token")
    private  String refreshToken;
    @JSONField( name="as:client_id")
    private  String client_id;
    @JSONField(name=".issued")
    private  String issued;
    @JSONField(name=".expires")
    private  String expires;

    private  String error;

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public String getTokenType() {
        return tokenType;
    }

    public void setTokenType(String tokenType) {
        this.tokenType = tokenType;
    }

    public String getExpiresIn() {
        return expiresIn;
    }

    public void setExpiresIn(String expiresIn) {
        this.expiresIn = expiresIn;
    }

    public String getRefreshToken() {
        return refreshToken;
    }

    public void setRefreshToken(String refreshToken) {
        this.refreshToken = refreshToken;
    }

    public String getClient_id() {
        return client_id;
    }

    public void setClient_id(String client_id) {
        this.client_id = client_id;
    }

    public String getIssued() {
        return issued;
    }

    public void setIssued(String issued) {
        this.issued = issued;
    }

    public String getExpires() {
        return expires;
    }

    public void setExpires(String expires) {
        this.expires = expires;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }
}

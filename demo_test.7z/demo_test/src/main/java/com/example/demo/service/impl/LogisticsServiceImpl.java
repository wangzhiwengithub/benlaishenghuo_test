package com.example.demo.service.impl;

import com.example.demo.client.LogisticsClient;
import com.example.demo.model.Dto.response.BaseResponseDto;
import com.example.demo.model.Dto.response.logistics.DoLogListResultDto;
import com.example.demo.model.Dto.response.logistics.FreightResultDto;
import com.example.demo.service.LogisticsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("logisticsService")
public class LogisticsServiceImpl implements LogisticsService {
    @Autowired
    private LogisticsClient logisticsClient;
    @Override
    public DoLogListResultDto get(String outTradeNo) {
        return logisticsClient.get(outTradeNo).getValue();
    }

    @Override
    public FreightResultDto getFreight(String province, String city, String county) {
        BaseResponseDto<FreightResultDto> result= logisticsClient.getfreight(province,city,county);
        return  result.getValue();
    }
}

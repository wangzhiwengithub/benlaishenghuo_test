package com.example.demo.client;

import com.example.demo.config.PartnerConfig;

import com.example.demo.model.Dto.request.order.CancelInfoDto;
import com.example.demo.model.Dto.request.order.ConfirmInfoDto;
import com.example.demo.model.Dto.request.order.CreateInfoDto;
import com.example.demo.model.Dto.request.order.QueryOrderDto;
import com.example.demo.model.Dto.response.*;

import com.example.demo.model.Dto.response.order.*;
import com.example.demo.model.configEnum.UrlEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.LinkedHashMap;
import java.util.Map;
@Component
public class OrderClient extends BenLaiBaseClient {

/*
    @Autowired
    private PartnerConfig config;*/
    public BaseResponseDto<CreateResultDto> createOrder(CreateInfoDto info){
        return   post( UrlEnum.ORDERCREATE.getUrl(),info,CreateResultDto.class);
    }

    public BaseResponseDto<ConfirmResultDto> confirmOrder(ConfirmInfoDto info){
        return   post( UrlEnum.ORDERCONFIRM.getUrl(),info,ConfirmResultDto.class);
    }

    public BaseResponseDto<CancelResultDto> cancelOrder(CancelInfoDto info){
        return   post( UrlEnum.ORDERCANCLE.getUrl(),info,CancelResultDto.class);
    }

    public BaseResponseDto<QueryDoResultDto> queryDo(String doId) {
        Map<String, Object> params = new LinkedHashMap<>();
        params.put("do_id", doId);
        return get(UrlEnum.QUERYDO.getUrl(), params, QueryDoResultDto.class);
    }
    public BaseResponseDto<QueryResultDto> queryOrder(QueryOrderDto info){
        Map<String,Object> params  = new LinkedHashMap<>();
        params.put("out_trade_no", info.getOutTradeNo());
        params.put("order_id", info.getOrderId());
        return   get(UrlEnum.QUERYORDER.getUrl(), params,  QueryResultDto.class);
    }



    }










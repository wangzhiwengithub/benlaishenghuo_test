package com.example.demo.controller;

import com.example.demo.model.Dto.response.category.CategoryResult;
import com.example.demo.service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("open/Category")
public class CategoryController {
    @Autowired
    private CategoryService categoryService;
    @RequestMapping(value = "/categoryOne", method = RequestMethod.GET)
    @ResponseBody
    public CategoryResult categoryOne() {
        return categoryService.categoryOne();
    }
    @RequestMapping(value = "/categoryTwo", method = RequestMethod.GET)
    @ResponseBody
    public CategoryResult categoryTwo() {
        return categoryService.categoryTwo();
    }
    @RequestMapping(value = "/categoryThree", method = RequestMethod.GET)
    @ResponseBody
    public CategoryResult categoryThree() {
        return categoryService.categoryThree();
    }
}

package com.example.demo.model.Dto.request.invoice;

public class BillInfo {
    private String billContact ;
    private String billPhone ;
    private String billProvince ;
    private String billCity ;
    private String billCounty ;
    private String billAddress ;

    public String getBillContact() {
        return billContact;
    }

    public void setBillContact(String billContact) {
        this.billContact = billContact;
    }

    public String getBillPhone() {
        return billPhone;
    }

    public void setBillPhone(String billPhone) {
        this.billPhone = billPhone;
    }

    public String getBillProvince() {
        return billProvince;
    }

    public void setBillProvince(String billProvince) {
        this.billProvince = billProvince;
    }

    public String getBillCity() {
        return billCity;
    }

    public void setBillCity(String billCity) {
        this.billCity = billCity;
    }

    public String getBillCounty() {
        return billCounty;
    }

    public void setBillCounty(String billCounty) {
        this.billCounty = billCounty;
    }

    public String getBillAddress() {
        return billAddress;
    }

    public void setBillAddress(String billAddress) {
        this.billAddress = billAddress;
    }
}

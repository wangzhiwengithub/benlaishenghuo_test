package com.example.demo.client;

import com.example.demo.model.Dto.response.Area.AreaResultDto;
import com.example.demo.model.Dto.response.BaseResponseDto;
import com.example.demo.model.Dto.response.category.CategoryResult;
import com.example.demo.model.configEnum.UrlEnum;
import org.springframework.stereotype.Component;

import java.util.LinkedHashMap;
import java.util.Map;

@Component
public class CategoryClient extends  BenLaiBaseClient {

    public BaseResponseDto<CategoryResult> categoryOne(){
        Map<String, Object> params = new LinkedHashMap<>();
        return get(UrlEnum.CATEGORYONE.getUrl(), null, CategoryResult.class);
    }
    public BaseResponseDto<CategoryResult> categoryTwo(){
        Map<String, Object> params = new LinkedHashMap<>();
        return get(UrlEnum.CATEGORYTWO.getUrl(), null, CategoryResult.class);
    }
    public BaseResponseDto<CategoryResult> categoryThree(){

        return get(UrlEnum.CATEGORYTHREE.getUrl(), null, CategoryResult.class);
    }
}

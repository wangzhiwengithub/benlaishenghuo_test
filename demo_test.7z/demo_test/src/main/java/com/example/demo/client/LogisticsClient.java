package com.example.demo.client;

import com.example.demo.model.Dto.request.order.ConfirmInfoDto;
import com.example.demo.model.Dto.response.BaseResponseDto;
import com.example.demo.model.Dto.response.logistics.DoLogListResultDto;
import com.example.demo.model.Dto.response.logistics.FreightResultDto;
import com.example.demo.model.Dto.response.order.ConfirmResultDto;
import com.example.demo.model.Dto.response.order.QueryDoResultDto;
import com.example.demo.model.configEnum.UrlEnum;
import org.springframework.stereotype.Component;

import java.util.LinkedHashMap;
import java.util.Map;

@Component
public class LogisticsClient extends BenLaiBaseClient {
    public BaseResponseDto<DoLogListResultDto> get(String outTradeNo){
        Map<String, Object> params = new LinkedHashMap<>();
        params.put("out_trade_no", outTradeNo);
        return get(UrlEnum.LOGISTICGET.getUrl(), params, DoLogListResultDto.class);
    }
    public BaseResponseDto<FreightResultDto> getfreight( String province,String city,String county){
        Map<String, Object> params = new LinkedHashMap<>();
        params.put("province", province);
        params.put("city", city);
        params.put("county", county);
        return get(UrlEnum.LOGISTICGETFreight.getUrl(), params, FreightResultDto.class);
    }
}

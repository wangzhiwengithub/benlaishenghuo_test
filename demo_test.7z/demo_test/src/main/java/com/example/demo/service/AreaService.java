package com.example.demo.service;

import com.example.demo.model.Dto.response.Area.AreaResultDto;

public interface AreaService {

    AreaResultDto get();
}

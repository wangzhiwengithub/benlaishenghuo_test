package com.example.demo.mapper;

import com.example.demo.entity.SkuDetailImgDO;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 商品详情图片表 Mapper 接口
 * </p>
 *
 * @author generator@Wangzhiwen
 * @since 2021-02-02
 */
public interface SkuDetailImgMapper extends BaseMapper<SkuDetailImgDO> {

}

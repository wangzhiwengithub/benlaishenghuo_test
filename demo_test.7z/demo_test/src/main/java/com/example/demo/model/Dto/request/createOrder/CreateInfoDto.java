package com.example.demo.model.Dto.request.createOrder;

import com.alibaba.fastjson.annotation.JSONField;

import java.math.BigDecimal;
import java.util.List;

public class CreateInfoDto {
  //  @JsonProperty(value="out_trade_no")
    @JSONField(name="out_trade_no")
    private String outTradeNo;
    @JSONField(name="receive_contact")
    private String receiveContact;
    @JSONField(name="receive_phone")
    private String receivePhone;
    private String province;
    private String city;
    private String county;
    @JSONField(name="receive_address")
    private String receivePddress;
    @JSONField(name="order_price")
    private BigDecimal orderPrice;
    @JSONField(name="ship_price")
    private BigDecimal shipPrice;
    @JSONField(name="order_detail")
    private List<CreateItemInfoDto> orderDetail;

    public String getOutTradeNo() {
        return outTradeNo;
    }

    public void setOutTradeNo(String outTradeNo) {
        this.outTradeNo = outTradeNo;
    }

    public String getReceiveContact() {
        return receiveContact;
    }

    public void setReceiveContact(String receiveContact) {
        this.receiveContact = receiveContact;
    }

    public String getReceivePhone() {
        return receivePhone;
    }

    public void setReceivePhone(String receivePhone) {
        this.receivePhone = receivePhone;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getReceivePddress() {
        return receivePddress;
    }

    public void setReceivePddress(String receivePddress) {
        this.receivePddress = receivePddress;
    }

    public BigDecimal getOrderPrice() {
        return orderPrice;
    }

    public void setOrderPrice(BigDecimal orderPrice) {
        this.orderPrice = orderPrice;
    }

    public BigDecimal getShipPrice() {
        return shipPrice;
    }

    public void setShipPrice(BigDecimal shipPrice) {
        this.shipPrice = shipPrice;
    }

    public List<CreateItemInfoDto> getOrderDetail() {
        return orderDetail;
    }

    public void setOrderDetail(List<CreateItemInfoDto> orderDetail) {
        this.orderDetail = orderDetail;
    }
}

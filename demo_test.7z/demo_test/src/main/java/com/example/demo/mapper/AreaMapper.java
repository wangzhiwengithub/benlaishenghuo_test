package com.example.demo.mapper;

import com.example.demo.entity.AreaDO;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 地区字典表 Mapper 接口
 * </p>
 *
 * @author generator@Wangzhiwen
 * @since 2021-01-29
 */

public interface AreaMapper extends BaseMapper<AreaDO> {

}

package com.example.demo.model.Dto.response.invoice;

import com.example.demo.model.Dto.response.ErrorResponseDto;

import java.util.List;

public class InventoryResult extends ErrorResponseDto {
    private List<InventoryDto> productList;

    public List<InventoryDto> getProductList() {
        return productList;
    }

    public void setProductList(List<InventoryDto> productList) {
        this.productList = productList;
    }
}

package com.example.demo.model.Dto.response;

import com.alibaba.fastjson.annotation.JSONField;

public class ErrorResponseDto {
    @JSONField(name="sub_code")
    private String subCode;
    @JSONField(name="sub_msg")
    private String subMsg;

    public String getSubCode() {
        return subCode;
    }

    public void setSubCode(String subCode) {
        this.subCode = subCode;
    }

    public String getSubMsg() {
        return subMsg;
    }

    public void setSubMsg(String subMsg) {
        this.subMsg = subMsg;
    }
}

package com.example.demo.common;

import java.util.stream.Stream;

public enum BenlaiDoStatus {
    DO_STATUS_INITIAL(1, "出库单初始"),
    DO_STATUS_DELIVERY(2, "出库单发出"),
    DO_STATUS_COMPLETE(3, "出库单签收");

    private Integer value;

    public Integer getValue() {
        return this.value;
    }

    BenlaiDoStatus(Integer value, String description) {
        this.value = value;
    }

    public static BenlaiDoStatus toType(int value) {
        return Stream.of(BenlaiDoStatus.values())
                .filter(c -> c.value == value)
                .findAny()
                .orElse(null);
    }
}

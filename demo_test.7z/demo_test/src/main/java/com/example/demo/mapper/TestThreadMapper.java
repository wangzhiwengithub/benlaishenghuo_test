package com.example.demo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 测试thread Mapper 接口
 * </p>
 *
 * @author generator@Wangzhiwen
 * @since 2021-02-09
 */
public interface TestThreadMapper extends BaseMapper<TestThreadDO> {

}

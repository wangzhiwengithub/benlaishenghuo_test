package com.example.demo.model.Dto.response.product;

import com.example.demo.model.Dto.response.ErrorResponseDto;

import java.util.List;

public class ProductImageResult  extends ErrorResponseDto {
    private List<ProductImageDto> images ;

    public List<ProductImageDto> getImages() {
        return images;
    }

    public void setImages(List<ProductImageDto> images) {
        this.images = images;
    }
}

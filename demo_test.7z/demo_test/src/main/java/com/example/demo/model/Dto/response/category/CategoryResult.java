package com.example.demo.model.Dto.response.category;

import com.example.demo.model.Dto.response.ErrorResponseDto;

import java.util.List;

public class CategoryResult extends ErrorResponseDto {
    private List<CategoryInfo> categoryList;

    public List<CategoryInfo> getCategoryList() {
        return categoryList;
    }

    public void setCategoryList(List<CategoryInfo> categoryList) {
        this.categoryList = categoryList;
    }
}

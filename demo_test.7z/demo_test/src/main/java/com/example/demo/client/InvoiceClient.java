package com.example.demo.client;

import com.example.demo.model.Dto.request.invoice.InvoiceCreateInfo;

import com.example.demo.model.Dto.response.Area.AreaResultDto;
import com.example.demo.model.Dto.response.BaseResponseDto;
import com.example.demo.model.Dto.response.invoice.InvoiceCreateResult;
import com.example.demo.model.Dto.response.invoice.InvoiceGetResult;
import com.example.demo.model.configEnum.UrlEnum;
import org.springframework.stereotype.Component;

import java.util.LinkedHashMap;
import java.util.Map;

@Component
public class InvoiceClient extends  BenLaiBaseClient {

    public BaseResponseDto<InvoiceCreateResult> create(InvoiceCreateInfo info) {

        return post(UrlEnum.INVOICECREATE.getUrl(), info, InvoiceCreateResult.class);
    }

    public BaseResponseDto<InvoiceGetResult> get(String markID,String invoiceId){
        Map<String, Object> params = new LinkedHashMap<>();
        params.put("mark_id",markID);
        params.put("invoice_id",invoiceId);
        return get(UrlEnum.INVOICEGET.getUrl(), params, InvoiceGetResult.class);
    }
}

package com.example.demo.model.Dto.response.aftersale;

import com.example.demo.model.Dto.response.ErrorResponseDto;

import java.util.List;

public class AvailableResultDto extends ErrorResponseDto {
    private List<AvailableProductResult> product_list;

    public List<AvailableProductResult> getProduct_list() {
        return product_list;
    }

    public void setProduct_list(List<AvailableProductResult> product_list) {
        this.product_list = product_list;
    }
}

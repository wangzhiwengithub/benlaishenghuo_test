package com.example.demo.model.Dto.response.aftersale;

import com.example.demo.model.Dto.response.ErrorResponseDto;

import java.math.BigDecimal;
import java.util.List;

public class GetRMAResultDto extends ErrorResponseDto {
    private String rmaId ;
    private String type ;
    private String rmaStatus ;
    private String rmaStatusRemark ;
    private String canCancel ;
    private String outTradeNo ;
    private String orderId ;
    private String doId ;
    private BigDecimal rmaAmount ;
    private String description ;
    private List<String> descriptionImg ;
    private String contact ;
    private String phone ;
    private String telephone ;
    private String province ;
    private String city ;
    private String county ;
    private String receiveaddress ;
    private List<GetRMAProductDetailResult> Productlist ;

    public String getRmaId() {
        return rmaId;
    }

    public void setRmaId(String rmaId) {
        this.rmaId = rmaId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getRmaStatus() {
        return rmaStatus;
    }

    public void setRmaStatus(String rmaStatus) {
        this.rmaStatus = rmaStatus;
    }

    public String getRmaStatusRemark() {
        return rmaStatusRemark;
    }

    public void setRmaStatusRemark(String rmaStatusRemark) {
        this.rmaStatusRemark = rmaStatusRemark;
    }

    public String getCanCancel() {
        return canCancel;
    }

    public void setCanCancel(String canCancel) {
        this.canCancel = canCancel;
    }

    public String getOutTradeNo() {
        return outTradeNo;
    }

    public void setOutTradeNo(String outTradeNo) {
        this.outTradeNo = outTradeNo;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getDoId() {
        return doId;
    }

    public void setDoId(String doId) {
        this.doId = doId;
    }

    public BigDecimal getRmaAmount() {
        return rmaAmount;
    }

    public void setRmaAmount(BigDecimal rmaAmount) {
        this.rmaAmount = rmaAmount;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<String> getDescriptionImg() {
        return descriptionImg;
    }

    public void setDescriptionImg(List<String> descriptionImg) {
        this.descriptionImg = descriptionImg;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getReceiveaddress() {
        return receiveaddress;
    }

    public void setReceiveaddress(String receiveaddress) {
        this.receiveaddress = receiveaddress;
    }

    public List<GetRMAProductDetailResult> getProductlist() {
        return Productlist;
    }

    public void setProductlist(List<GetRMAProductDetailResult> productlist) {
        Productlist = productlist;
    }
}

package com.example.demo.service;

import com.example.demo.model.Dto.request.invoice.InvoiceCreateInfo;
import com.example.demo.model.Dto.response.invoice.InvoiceCreateResult;
import com.example.demo.model.Dto.response.invoice.InvoiceGetResult;

public interface InvoiceService {
    InvoiceCreateResult create(InvoiceCreateInfo info);
    InvoiceGetResult get(String markID, String invoiceId);
}

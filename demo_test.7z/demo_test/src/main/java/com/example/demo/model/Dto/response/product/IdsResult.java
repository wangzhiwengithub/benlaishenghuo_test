package com.example.demo.model.Dto.response.product;

import com.example.demo.model.Dto.response.ErrorResponseDto;

import java.util.List;

public class IdsResult extends ErrorResponseDto {
    private  List<String> productIds;

    public List<String> getProductIds() {
        return productIds;
    }

    public void setProductIds(List<String> productIds) {
        this.productIds = productIds;
    }

}

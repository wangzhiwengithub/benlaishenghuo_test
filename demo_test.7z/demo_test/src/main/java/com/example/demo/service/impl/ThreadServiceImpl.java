package com.example.demo.service.impl;

import com.example.demo.mapper.TestThreadMapper;
import com.example.demo.service.ThreadService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ThreadServiceImpl implements ThreadService {
    @Autowired
    private TestThreadMapper testThreadMapper;

    @Override
    public void testThread(int k) {
        for (int i = 0; i < 10; i++) {
            TestThreadDO testThreadDO = new TestThreadDO();
            testThreadDO.setEmployeeNo("Thread-" + k + "-employee" + i);
            testThreadDO.setName("Thread-" + k + "-wangzhiwen" + i);
            testThreadMapper.insert(testThreadDO);
        }
    }
}

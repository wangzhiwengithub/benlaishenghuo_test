package com.example.demo.mapper;

import com.example.demo.entity.OrderDO;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 订单表 Mapper 接口
 * </p>
 *
 * @author generator@Wangzhiwen
 * @since 2021-02-07
 */
public interface OrderMapper extends BaseMapper<OrderDO> {

}

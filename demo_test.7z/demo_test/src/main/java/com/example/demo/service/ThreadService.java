package com.example.demo.service;

import com.example.demo.mapper.TestThreadMapper;

public interface ThreadService {
    void testThread(int i);
}

package com.example.demo.model.Dto.response.Area;

import com.example.demo.model.Dto.response.ErrorResponseDto;

import java.util.List;

public class AreaResultDto  extends ErrorResponseDto {
    private List<AreaModel> addrAll;

    public List<AreaModel> getAddrAll() {
        return addrAll;
    }

    public void setAddrAll(List<AreaModel> addrAll) {
        this.addrAll = addrAll;
    }
}

package com.example.demo.client;

import com.example.demo.model.Dto.response.Area.AreaResultDto;
import com.example.demo.model.Dto.response.BaseResponseDto;

import com.example.demo.model.configEnum.UrlEnum;
import org.springframework.stereotype.Component;

import java.util.LinkedHashMap;
import java.util.Map;
@Component
public class AreaClient extends  BenLaiBaseClient {

    public BaseResponseDto<AreaResultDto> get(){
        Map<String, Object> params = new LinkedHashMap<>();
        return get(UrlEnum.AREAGET.getUrl(), params, AreaResultDto.class);
    }
}

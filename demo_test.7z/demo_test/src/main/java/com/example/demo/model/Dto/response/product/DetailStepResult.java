package com.example.demo.model.Dto.response.product;

public class DetailStepResult {
    /// <summary>步骤名称 </summary>
    private String name ;
    /// <summary>主料 </summary>
    private String mainIngredient ;
    /// <summary>辅料 </summary>
    private String accessory ;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMainIngredient() {
        return mainIngredient;
    }

    public void setMainIngredient(String mainIngredient) {
        this.mainIngredient = mainIngredient;
    }

    public String getAccessory() {
        return accessory;
    }

    public void setAccessory(String accessory) {
        this.accessory = accessory;
    }
}

package com.example.demo.model.Dto.response.logistics;

import java.util.List;

public class DoLogListResultDto {
    public List<LogisticsResponse> logistics_list;

    public List<LogisticsResponse> getLogistics_list() {
        return logistics_list;
    }

    public void setLogistics_list(List<LogisticsResponse> logistics_list) {
        this.logistics_list = logistics_list;
    }
}

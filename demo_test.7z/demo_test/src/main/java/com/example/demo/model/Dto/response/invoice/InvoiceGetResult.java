package com.example.demo.model.Dto.response.invoice;

import com.example.demo.model.Dto.response.ErrorResponseDto;

import java.math.BigDecimal;
import java.util.List;

public class InvoiceGetResult extends ErrorResponseDto {

    private String markId ;

    private String invoiceId ;
    private String content ;
    private String invoiceType ;
    private String invoiceStutes ;
    private String invoiceStutesRemark ;


    /// <summary>
    /// 申请未税金额
    /// </summary>
    private BigDecimal applyAmt ;
    /// <summary>
    /// 申请含税金额
    /// </summary>
    private BigDecimal applyTaxAmt ;
    /// <summary>
    /// 发票未税金额
    /// </summary>
    private BigDecimal invoiceAmt ;
    /// <summary>
    /// 发票含税金额
    /// </summary>
    private BigDecimal invoiceTaxAmt ;
    /// <summary>
    /// 发票明细
    /// </summary>
    private List<InvoiceDto> invoiceList ;

    public String getMarkId() {
        return markId;
    }

    public void setMarkId(String markId) {
        this.markId = markId;
    }

    public String getInvoiceId() {
        return invoiceId;
    }

    public void setInvoiceId(String invoiceId) {
        this.invoiceId = invoiceId;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getInvoiceType() {
        return invoiceType;
    }

    public void setInvoiceType(String invoiceType) {
        this.invoiceType = invoiceType;
    }

    public String getInvoiceStutes() {
        return invoiceStutes;
    }

    public void setInvoiceStutes(String invoiceStutes) {
        this.invoiceStutes = invoiceStutes;
    }

    public String getInvoiceStutesRemark() {
        return invoiceStutesRemark;
    }

    public void setInvoiceStutesRemark(String invoiceStutesRemark) {
        this.invoiceStutesRemark = invoiceStutesRemark;
    }

    public BigDecimal getApplyAmt() {
        return applyAmt;
    }

    public void setApplyAmt(BigDecimal applyAmt) {
        this.applyAmt = applyAmt;
    }

    public BigDecimal getApplyTaxAmt() {
        return applyTaxAmt;
    }

    public void setApplyTaxAmt(BigDecimal applyTaxAmt) {
        this.applyTaxAmt = applyTaxAmt;
    }

    public BigDecimal getInvoiceAmt() {
        return invoiceAmt;
    }

    public void setInvoiceAmt(BigDecimal invoiceAmt) {
        this.invoiceAmt = invoiceAmt;
    }

    public BigDecimal getInvoiceTaxAmt() {
        return invoiceTaxAmt;
    }

    public void setInvoiceTaxAmt(BigDecimal invoiceTaxAmt) {
        this.invoiceTaxAmt = invoiceTaxAmt;
    }

    public List<InvoiceDto> getInvoiceList() {
        return invoiceList;
    }

    public void setInvoiceList(List<InvoiceDto> invoiceList) {
        this.invoiceList = invoiceList;
    }
}

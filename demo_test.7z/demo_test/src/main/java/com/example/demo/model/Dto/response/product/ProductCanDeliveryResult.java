package com.example.demo.model.Dto.response.product;

import java.util.List;

public class ProductCanDeliveryResult {
    //    {
//        "code":0,
//            "msg":"success",
//            "value":{
//        "area_list":[
//        {
//            "province_id":26,
//                "province_name":"上海市",
//                "city_id":120,
//                "city_name":"上海市",
//                "district_id":1090,
//                "district_name":"黄浦区"
//        },
//        {
//            "province_id":26,
//                "province_name":"上海市",
//                "city_id":120,
//                "city_name":"上海市",
//                "district_id":1092,
//                "district_name":"徐汇区"
//        }
//        ]
//    }
//    }
    private List<DeliveryAreaDto> areaList;

    public List<DeliveryAreaDto> getAreaList() {
        return areaList;
    }

    public void setAreaList(List<DeliveryAreaDto> areaList) {
        this.areaList = areaList;
    }
}

package com.example.demo.config;


import org.springframework.stereotype.Component;

import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.Base64;
import java.util.Properties;

@Component
public class PartnerConfig {



    private String id;
    private String secret;
    private String Authorization;


    public PartnerConfig() {
        Properties properties;
        try {
            properties = loadPropertiesFromResource("application.properties");
            this.id = properties.getProperty("id");
            this.secret = properties.getProperty("secret");
            this.Authorization=getAuthorization();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private static Properties loadPropertiesFromResource(String resource) throws Exception {
        try (InputStream inputStream = PartnerConfig.class.getClassLoader().getResourceAsStream(resource);) {
            Properties properties = new Properties();
            properties.load(inputStream);
            return properties;
        }
    }

    public String getAuthorization() throws UnsupportedEncodingException {
        StringBuffer authorization=new StringBuffer("Basic ");
        StringBuffer sb=new StringBuffer();
        sb.append(this.id);
        sb.append(":");
        sb.append(this.secret);
        return   authorization.append(Base64.getEncoder().encodeToString(sb.toString().getBytes("UTF-8"))).toString();
    }
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSecret() {
        return secret;
    }

    public void setSecret(String secret) {
        this.secret = secret;
    }

    public void setAuthorization(String authorization) {
        Authorization = authorization;
    }


}

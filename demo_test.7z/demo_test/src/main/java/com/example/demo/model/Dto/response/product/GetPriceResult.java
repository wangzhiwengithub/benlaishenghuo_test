package com.example.demo.model.Dto.response.product;

import com.example.demo.model.Dto.response.ErrorResponseDto;

import java.util.List;

public class GetPriceResult extends ErrorResponseDto {
    private List<ProductPriceDto> priceList ;

    public List<ProductPriceDto> getPriceList() {
        return priceList;
    }

    public void setPriceList(List<ProductPriceDto> priceList) {
        this.priceList = priceList;
    }
}

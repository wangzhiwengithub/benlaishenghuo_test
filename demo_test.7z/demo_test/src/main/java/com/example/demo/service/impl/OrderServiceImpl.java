package com.example.demo.service.impl;

import com.example.demo.client.TokenClient;
import com.example.demo.model.Dto.request.order.CancelInfoDto;
import com.example.demo.model.Dto.request.order.ConfirmInfoDto;
import com.example.demo.model.Dto.request.order.CreateInfoDto;
import com.example.demo.model.Dto.request.order.QueryOrderDto;
import com.example.demo.model.Dto.response.BaseResponseDto;

import com.example.demo.model.Dto.response.order.*;

import com.example.demo.service.OrderService;
import com.example.demo.client.OrderClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("orderService")
public class OrderServiceImpl implements OrderService {
    @Autowired
    private OrderClient order;
    @Autowired
    private TokenClient token;

    @Override
    public CreateResultDto createOrder(CreateInfoDto info) {
        //todo
       /*
        1.订单建立订单表，根据流程设置标志位，标识订单状态
        2.本来生活有订单字典表（1.订单状态字典表；2.订单状态描述字典表）
          字典表看数量多不，或者关键的状态，用枚举去存储
        3.工具类：导入porter中的id生成类，或者自定义规则生成订单单号
                 注意预下单有一个单号，订单确认也有一个单号，然后预下单
                 有一个超时时间，需要一个字段去记录？如果预下单完成之后，
                 正式下单失败，重新订单确认，和这个超时时间需要判断，相应的流程怎么制定，
                 异常订单重试用任务去跑？
        4.订单查询有个出库单单号列表字段，这个数据要怎么处理？
          已有平台的有出库单相应的表，do？
        */
        BaseResponseDto<CreateResultDto> result = order.createOrder(info);
        return result.getValue();

    }

    @Override
    public ConfirmResultDto confirmOrder(ConfirmInfoDto info) {
        BaseResponseDto<ConfirmResultDto> result = order.confirmOrder(info);
        return result.getValue();
    }

    @Override
    public QueryDoResultDto queryDo(String doID) {
        BaseResponseDto<QueryDoResultDto> result = order.queryDo(doID);
        return result.getValue();
    }

    @Override
    public QueryResultDto queryOrder(QueryOrderDto info) {

        BaseResponseDto<QueryResultDto> result = order.queryOrder(info);
        return result.getValue();
    }

    @Override
    public CancelResultDto cancelOrder(CancelInfoDto info) {
        BaseResponseDto<CancelResultDto> result = order.cancelOrder(info);
        return result.getValue();
    }


}


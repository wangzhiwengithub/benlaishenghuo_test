package com.example.demo.model.Dto.request.invoice;

import com.example.demo.model.Dto.response.ErrorResponseDto;

import java.math.BigDecimal;
import java.util.List;

public class InvoiceCreateInfo   {
    private List<String> outTradeNoList ;

    /// <summary>
    /// 第三方申请单号
    /// </summary>
    private String markId ;

    private String invoiceType ;

    private String content ;

    private String invoiceAte ;

    private String title ;


    private String billingAddress ;
    private String billingPhone ;
    private String taxNo ;
    private String bankName ;
    private String bankAccount ;

    private BigDecimal applyAmt ;

    private BigDecimal applyTaAamt ;
    private BillInfo bill ;

    public List<String> getOutTradeNoList() {
        return outTradeNoList;
    }

    public void setOutTradeNoList(List<String> outTradeNoList) {
        this.outTradeNoList = outTradeNoList;
    }

    public String getMarkId() {
        return markId;
    }

    public void setMarkId(String markId) {
        this.markId = markId;
    }

    public String getInvoiceType() {
        return invoiceType;
    }

    public void setInvoiceType(String invoiceType) {
        this.invoiceType = invoiceType;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getInvoiceAte() {
        return invoiceAte;
    }

    public void setInvoiceAte(String invoiceAte) {
        this.invoiceAte = invoiceAte;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getBillingAddress() {
        return billingAddress;
    }

    public void setBillingAddress(String billingAddress) {
        this.billingAddress = billingAddress;
    }

    public String getBillingPhone() {
        return billingPhone;
    }

    public void setBillingPhone(String billingPhone) {
        this.billingPhone = billingPhone;
    }

    public String getTaxNo() {
        return taxNo;
    }

    public void setTaxNo(String taxNo) {
        this.taxNo = taxNo;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public String getBankAccount() {
        return bankAccount;
    }

    public void setBankAccount(String bankAccount) {
        this.bankAccount = bankAccount;
    }

    public BigDecimal getApplyAmt() {
        return applyAmt;
    }

    public void setApplyAmt(BigDecimal applyAmt) {
        this.applyAmt = applyAmt;
    }

    public BigDecimal getApplyTaAamt() {
        return applyTaAamt;
    }

    public void setApplyTaAamt(BigDecimal applyTaAamt) {
        this.applyTaAamt = applyTaAamt;
    }

    public BillInfo getBill() {
        return bill;
    }

    public void setBill(BillInfo bill) {
        this.bill = bill;
    }
}

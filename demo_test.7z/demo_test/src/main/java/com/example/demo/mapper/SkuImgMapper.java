package com.example.demo.mapper;

import com.example.demo.entity.SkuImgDO;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 商品图片表 Mapper 接口
 * </p>
 *
 * @author generator@Wangzhiwen
 * @since 2021-02-01
 */
public interface SkuImgMapper extends BaseMapper<SkuImgDO> {

}

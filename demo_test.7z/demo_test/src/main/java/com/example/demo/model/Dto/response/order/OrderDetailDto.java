package com.example.demo.model.Dto.response.order;

import com.alibaba.fastjson.annotation.JSONField;

import java.math.BigDecimal;

public class OrderDetailDto {
    @JSONField(name = "product_id")
    private String productID;
    @JSONField(name = "product_name")
    private String productName;
    private int quantity;
    private BigDecimal price;


    public String getProductID() {
        return productID;
    }

    public void setProductID(String productID) {
        this.productID = productID;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }
}

package com.example.demo.model.Dto.response.product;

public class PoductupdownstatusDto {

    private  String productId;
    private  String updownstatus;

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getUpdownstatus() {
        return updownstatus;
    }

    public void setUpdownstatus(String updownstatus) {
        this.updownstatus = updownstatus;
    }
}

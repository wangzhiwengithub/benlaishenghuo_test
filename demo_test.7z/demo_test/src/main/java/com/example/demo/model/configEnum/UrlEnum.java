package com.example.demo.model.configEnum;

public enum UrlEnum {




    DOMAIN("http://openapitestb.benlai.com","本来生活OpenApi域名"),
    TOKEN("/token","获取token接口"),
    ORDERCREATE("/api/V2/order/create","创建订单 "),
    ORDERCONFIRM("/api/V2/order/confirm","确定订单 "),
    ORDERCANCLE("/api/V2/order/cancel","取消订单"),
    QUERYORDER("/api/V2/order/query","查询订单"),
    QUERYDO("/api/V2/order/querydo","查询do单"),
    LOGISTICGET("/api/V2/Logistics/get","物流信息查询接口"),
    LOGISTICGETFreight("/api/V2/Logistics/getfreight","获取运费价格"),
    AFTERSALECREATE("/api/V2/AfterSale/create"),
    AFTERSALEAVAILABLE("/api/V2/AfterSale/available"),
    AFTERSALELIST("/api/V2/AfterSale/list"),
    AFTERSALEGET("/api/V2/AfterSale/get"),
    AFTERSALECANCEL("/api/V2/AfterSale/cancel"),
    AREAGET("/api/V2/Area/get"),
    CATEGORYONE("/api/V2/Category/categoryone"),
    CATEGORYTWO("/api/V2/Category/categorytwo"),
    CATEGORYTHREE("/api/V2/Category/categorythree"),

    INVOICECREATE("/api/V2/Invoice/create"),
    INVOICEGET("/api/V2/Invoice/get"),
    PRODUCTIDS("/api/V2/Product/ids"),
    PRODUCTITEM("/api/V2/Product/item"),
    PRODUCTIMEGES("/api/V2/Product/images"),
    PRODUCTDETAILS("/api/V2/Product/details"),
    PRODUCTINVENTORY("/api/V2/Product/inventory"),
    PRODUCTUPDOWNSTATUS("/api/V2/Product/updownstatus"),
    PRODUCTCHECKAREA("/api/V2/Product/checkarea"),
    PRODUCTGETPRICE("/api/V2/Product/getprice"),
    PRODUCTDELIVERYAREA("/api/V2/Product/deliveryArea"),


    ;

    private  String url;
    private  String msg;

    UrlEnum(String url, String msg) {
        this.url = url;
        this.msg = msg;
    }

    UrlEnum(String url) {
        this.url = url;
    }
    public String getUrl() {
        return url;
    }
    public void setUrl(String url) {
        this.url = url;
    }
}


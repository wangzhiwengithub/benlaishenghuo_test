package com.example.demo.model.Dto.response.product;

import java.math.BigDecimal;
import java.util.List;

public class ProductInfo {

    /// <summary>分销商品编号</summary>
    private String productId ;
    /// <summary>商品名称</summary>
    private String productName ;
    private int c1Id ;
    /// <summary>大类</summary>
    private String c1Name ;
    private int c2id ;
    /// <summary>中类</summary>
    private String c2Name ;
    private int c3id ;
    /// <summary>小类</summary>
    private String c3Name ;
    /// <summary>供应商</summary>
    private String vendor ;
    /// <summary>商品售价</summary>
    private BigDecimal price ;
    /// <summary>产地</summary>
    private String productionArea ;

    private List<ProductDeliveryAreaModel> deliveryArea ;

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public int getC1Id() {
        return c1Id;
    }

    public void setC1Id(int c1Id) {
        this.c1Id = c1Id;
    }

    public String getC1Name() {
        return c1Name;
    }

    public void setC1Name(String c1Name) {
        this.c1Name = c1Name;
    }

    public int getC2id() {
        return c2id;
    }

    public void setC2id(int c2id) {
        this.c2id = c2id;
    }

    public String getC2Name() {
        return c2Name;
    }

    public void setC2Name(String c2Name) {
        this.c2Name = c2Name;
    }

    public int getC3id() {
        return c3id;
    }

    public void setC3id(int c3id) {
        this.c3id = c3id;
    }

    public String getC3Name() {
        return c3Name;
    }

    public void setC3Name(String c3Name) {
        this.c3Name = c3Name;
    }

    public String getVendor() {
        return vendor;
    }

    public void setVendor(String vendor) {
        this.vendor = vendor;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public String getProductionArea() {
        return productionArea;
    }

    public void setProductionArea(String productionArea) {
        this.productionArea = productionArea;
    }

    public List<ProductDeliveryAreaModel> getDeliveryArea() {
        return deliveryArea;
    }

    public void setDeliveryArea(List<ProductDeliveryAreaModel> deliveryArea) {
        this.deliveryArea = deliveryArea;
    }
}

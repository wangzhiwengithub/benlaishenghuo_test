package com.example.demo.model.Dto.response.product;

import com.example.demo.model.Dto.response.ErrorResponseDto;

import java.util.List;

public class ProductDetailResult extends ErrorResponseDto {
    private String ImgUrl;
    private String nickName ;
    /// <summary>规格 </summary>
    private String model ;
    /// <summary>尺寸 </summary>
    private String size ;
    /// <summary>保质期 </summary>
    private String productionDate ;
    /// <summary>存储方式 </summary>
    private String storage ;

    /// <summary>图片路径 </summary>
    private String imgUrl;

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    /// <summary>食物特点 </summary>
    private List<DetailItemResult> features ;
    /// <summary>买手笔记 </summary>
    private List<DetailItemResult> buyers ;
    /// <summary>食用建议 </summary>
    private List<DetailItemResult> proposals ;
    /// <summary>品牌故事 </summary>
    private List<DetailItemResult> stories ;
    /// <summary>制作步骤 </summary>
    private List<DetailStepResult> steps ;

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getProductionDate() {
        return productionDate;
    }

    public void setProductionDate(String productionDate) {
        this.productionDate = productionDate;
    }

    public String getStorage() {
        return storage;
    }

    public void setStorage(String storage) {
        this.storage = storage;
    }

    public List<DetailItemResult> getFeatures() {
        return features;
    }

    public void setFeatures(List<DetailItemResult> features) {
        this.features = features;
    }

    public List<DetailItemResult> getBuyers() {
        return buyers;
    }

    public void setBuyers(List<DetailItemResult> buyers) {
        this.buyers = buyers;
    }

    public List<DetailItemResult> getProposals() {
        return proposals;
    }

    public void setProposals(List<DetailItemResult> proposals) {
        this.proposals = proposals;
    }

    public List<DetailItemResult> getStories() {
        return stories;
    }

    public void setStories(List<DetailItemResult> stories) {
        this.stories = stories;
    }

    public List<DetailStepResult> getSteps() {
        return steps;
    }

    public void setSteps(List<DetailStepResult> steps) {
        this.steps = steps;
    }
}

package com.example.demo.service;

import com.example.demo.model.Dto.response.BaseResponseDto;
import com.example.demo.model.Dto.response.invoice.InventoryResult;
import com.example.demo.model.Dto.response.product.*;
import com.example.demo.model.configEnum.UrlEnum;

import java.util.LinkedHashMap;
import java.util.Map;

public interface ProductService {


    IdsResult ids(Integer categoryId);

    ProductResult item(String productIds);


    ProductImageResult images(String productId);

    ProductDetailResult details(String productId);

    InventoryResult inventory(String productIds);

    ProductCanDeliveryResult delivery(String productId);


    UpdownstatusResult updownstatus(String productIds);

    //    CheckareaResult checkarea(String productIds);
    CheckareaResult checkarea(String productIds, String province, String city, String area);

    GetPriceResult getprice(String productIds);

    void syncProductIds();

    void syncProductMainInfo();

    void syncProductMainImages();

    void syncProductDetail();

    void syncProductOnlineStatus();

    void syncProductCanDeliverArea();

    void syncProductCanSaleArea();

    void syncProductPrices();

    void syncProductStocks();

    void syncCatetoryOne();

    void syncCatetoryTwo();

    void syncCatetoryThree();
}

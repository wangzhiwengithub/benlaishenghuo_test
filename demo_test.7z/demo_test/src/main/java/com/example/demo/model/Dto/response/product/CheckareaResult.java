package com.example.demo.model.Dto.response.product;

import com.example.demo.model.Dto.response.ErrorResponseDto;

import java.util.List;

public class CheckareaResult extends ErrorResponseDto {
    private List<SaleAreaDto> checkList ;

    public List<SaleAreaDto> getCheckList() {
        return checkList;
    }

    public void setCheckList(List<SaleAreaDto> checkList) {
        this.checkList = checkList;
    }
}

package com.example.demo.model.Dto.response.order;

import com.example.demo.model.Dto.response.ErrorResponseDto;

public class CancelResultDto extends ErrorResponseDto {

    private  boolean isClose;

    public boolean isClose() {
        return isClose;
    }

    public void setClose(boolean close) {
        isClose = close;
    }
}

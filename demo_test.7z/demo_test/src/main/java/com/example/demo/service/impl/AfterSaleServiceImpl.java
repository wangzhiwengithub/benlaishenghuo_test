package com.example.demo.service.impl;

import com.example.demo.client.AfterSaleClient;
import com.example.demo.model.Dto.request.aftersale.CancelInfoDto;
import com.example.demo.model.Dto.request.aftersale.CreateInfoDto;
import com.example.demo.model.Dto.response.aftersale.*;
import com.example.demo.service.AfterSaleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("afterSaleServic")
public class AfterSaleServiceImpl implements AfterSaleService {
    @Autowired
    private AfterSaleClient afterSaleClient;
    @Override
    public CreateResultDto create(CreateInfoDto info) {
        return afterSaleClient.create(info).getValue();
    }

    @Override
    public AvailableResultDto available(String doID) {
        return afterSaleClient.available(doID).getValue();
    }

    @Override
    public GetListResultDto list(String doID) {
        return afterSaleClient.list(doID).getValue();
    }

    @Override
    public GetRMAResultDto get(String rmaID) {
        return afterSaleClient.get(rmaID).getValue();
    }

    @Override
    public CancelResultDto cancel(CancelInfoDto info) {
        return afterSaleClient.cancel(info).getValue();
    }
}

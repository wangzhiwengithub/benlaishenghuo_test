package com.example.demo.model.Dto.request.aftersale;

public class CancelInfoDto {

    private String rmaId;

    public String getRmaId() {
        return rmaId;
    }

    public void setRmaId(String rmaId) {
        this.rmaId = rmaId;
    }
}

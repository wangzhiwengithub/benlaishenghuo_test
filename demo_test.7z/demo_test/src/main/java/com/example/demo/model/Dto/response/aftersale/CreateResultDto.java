package com.example.demo.model.Dto.response.aftersale;

import com.example.demo.model.Dto.response.ErrorResponseDto;

public class CreateResultDto extends ErrorResponseDto {
    private String rmaId;

    public String getRmaId() {
        return rmaId;
    }

    public void setRmaId(String rmaId) {
        this.rmaId = rmaId;
    }
}

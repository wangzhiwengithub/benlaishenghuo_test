package com.example.demo.model.Dto.response.aftersale;

import com.example.demo.model.Dto.response.ErrorResponseDto;

import java.math.BigDecimal;
import java.util.List;

public class GetListRMAResult   {
    private String rmaId ;
    private String type ;
    private String rmastatus ;
    private String rmaStatusRemark ;
    private String canCancel ;
    private String outTradeNo ;
    private String orderId ;
    private BigDecimal rmaAmount ;
    private List<GetListProductDetailResult> productList ;

    public String getRmaId() {
        return rmaId;
    }

    public void setRmaId(String rmaId) {
        this.rmaId = rmaId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getRmastatus() {
        return rmastatus;
    }

    public void setRmastatus(String rmastatus) {
        this.rmastatus = rmastatus;
    }

    public String getRmaStatusRemark() {
        return rmaStatusRemark;
    }

    public void setRmaStatusRemark(String rmaStatusRemark) {
        this.rmaStatusRemark = rmaStatusRemark;
    }

    public String getCanCancel() {
        return canCancel;
    }

    public void setCanCancel(String canCancel) {
        this.canCancel = canCancel;
    }

    public String getOutTradeNo() {
        return outTradeNo;
    }

    public void setOutTradeNo(String outTradeNo) {
        this.outTradeNo = outTradeNo;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public BigDecimal getRmaAmount() {
        return rmaAmount;
    }

    public void setRmaAmount(BigDecimal rmaAmount) {
        this.rmaAmount = rmaAmount;
    }

    public List<GetListProductDetailResult> getProductList() {
        return productList;
    }

    public void setProductList(List<GetListProductDetailResult> productList) {
        this.productList = productList;
    }
}

package com.example.demo.service.impl;

import com.example.demo.client.InvoiceClient;
import com.example.demo.model.Dto.request.invoice.InvoiceCreateInfo;
import com.example.demo.model.Dto.response.invoice.InvoiceCreateResult;
import com.example.demo.model.Dto.response.invoice.InvoiceGetResult;
import com.example.demo.service.InvoiceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("invoiceService")
public class InvoiceServiceImpl implements InvoiceService {
    @Autowired
    private InvoiceClient invoiceClient;
    @Override
    public InvoiceCreateResult create(InvoiceCreateInfo info) {
        return invoiceClient.create(info).getValue();
    }

    @Override
    public InvoiceGetResult get(String markID, String invoiceId) {
        return invoiceClient.get(markID,invoiceId).getValue();
    }
}

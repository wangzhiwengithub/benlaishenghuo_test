package com.example.demo.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;

import java.time.LocalDateTime;

import com.baomidou.mybatisplus.annotation.TableField;

import java.io.Serializable;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * 商品详情图片表
 *
 * @author generator@Wangzhiwen
 * @since 2021-02-02
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("sku_detail_img")
public class SkuDetailImgDO implements Serializable {


    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 商品详情id
     */
    private Integer skuDetailId;

    /**
     * 详情类型:(1:features;2:buyers;3:proposals;4:stories;5:steps)
     */
    private Integer type;

    /**
     * 排序从0开始步长为1
     */
    private Integer index;

    /**
     * 描述内容
     */
    private String content;

    /**
     * 本来生活商品详情图片路径
     */
    @TableField("benlai_detailImg")
    private String benlaiDetailimg;

    /**
     * 云书网商品详情图片路径
     */
    @TableField("yunshu_detailImg")
    private String yunshuDetailimg;

    private LocalDateTime createTime;

    private LocalDateTime updateTime;

    private LocalDateTime deleteTime;


}

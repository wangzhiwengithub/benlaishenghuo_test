package com.example.demo.common;

import java.util.stream.Stream;

/**
 * 本来生活订单状态枚举
 */
public enum BenlaiOrderStatus {

    ORDER_STATUS_INITIAL(1, "订单初始"),
    ORDER_STATUS_REVOKE(2, "订单作废"),
    ORDER_STATUS_CANCEL(3, "订单取消"),
    ORDER_STATUS_CONFIRM(4, "订单确认"),
    ORDER_STATUS_EXPRESS_WAIT(5, "订单商品待出库"),
    ORDER_STATUS_EXPRESS_PART(6, "订单商品部分出库"),
    ORDER_STATUS_EXPRESS_FULL(7, "订单商品全出库"),
    ORDER_STATUS_EXPRESS_COMPLETE(8, "订单商品妥投完成");

    private Integer value;

    public Integer getValue() {
        return this.value;
    }

    BenlaiOrderStatus(Integer value, String description) {
        this.value = value;
    }

    public static BenlaiOrderStatus toType(int value) {
        return Stream.of(BenlaiOrderStatus.values())
                .filter(c -> c.value == value)
                .findAny()
                .orElse(null);
    }

}

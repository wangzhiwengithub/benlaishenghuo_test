package com.example.demo.model.Dto.request.order;

import com.alibaba.fastjson.annotation.JSONField;
import com.example.demo.model.Dto.response.ErrorResponseDto;

public class QueryOrderDto extends ErrorResponseDto {
    private  String outTradeNo;
    private  String orderId;

    public String getOutTradeNo() {
        return outTradeNo;
    }

    public void setOutTradeNo(String outTradeNo) {
        this.outTradeNo = outTradeNo;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public QueryOrderDto(String outTradeNo, String orderId) {
        this.outTradeNo = outTradeNo;
        this.orderId = orderId;
    }

    public QueryOrderDto() {
    }
}

package com.example.demo.service;

import com.example.demo.model.Dto.response.logistics.DoLogListResultDto;
import com.example.demo.model.Dto.response.logistics.FreightResultDto;

public interface LogisticsService {

    DoLogListResultDto get(String outTradeNo);
    FreightResultDto getFreight(String province,String city,String county);
}

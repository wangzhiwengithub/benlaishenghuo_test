package com.example.demo.model.Dto.response.product;

public class DetailItemResult {
    private String ImgUrl;

    /// <summary>描述内容 </summary>
    private String content ;

    /// <summary>图片路径 </summary>
    private String imgUrl;

    public String getImgUrl() {
        return ImgUrl;
    }

    public void setImgUrl(String imgUrl) {
        ImgUrl = imgUrl;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}

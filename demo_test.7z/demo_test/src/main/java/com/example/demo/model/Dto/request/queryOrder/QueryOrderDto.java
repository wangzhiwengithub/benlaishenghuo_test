package com.example.demo.model.Dto.request.queryOrder;

import com.alibaba.fastjson.annotation.JSONField;
import com.example.demo.model.Dto.response.ErrorResponseDto;

public class QueryOrderDto extends ErrorResponseDto {
    @JSONField(name="out_trade_no")
    private  String outTradeNo;
    @JSONField(name="order_id")
    private  String orderId;

    public String getOutTradeNo() {
        return outTradeNo;
    }

    public void setOutTradeNo(String outTradeNo) {
        this.outTradeNo = outTradeNo;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public QueryOrderDto(String outTradeNo, String orderId) {
        this.outTradeNo = outTradeNo;
        this.orderId = orderId;
    }

    public QueryOrderDto() {
    }
}

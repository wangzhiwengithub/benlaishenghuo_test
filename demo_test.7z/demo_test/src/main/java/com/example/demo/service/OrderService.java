package com.example.demo.service;

import com.example.demo.model.Dto.request.order.CancelInfoDto;
import com.example.demo.model.Dto.request.order.ConfirmInfoDto;
import com.example.demo.model.Dto.request.order.CreateInfoDto;
import com.example.demo.model.Dto.request.order.QueryOrderDto;
import com.example.demo.model.Dto.response.order.*;

public interface OrderService {


    CreateResultDto createOrder(CreateInfoDto info);
    QueryResultDto queryOrder(QueryOrderDto info);
    CancelResultDto cancelOrder(CancelInfoDto info);
    ConfirmResultDto confirmOrder(ConfirmInfoDto info);
    QueryDoResultDto queryDo(String doID);

}

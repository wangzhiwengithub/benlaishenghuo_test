package com.example.demo.client;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.example.demo.config.PartnerConfig;
import com.example.demo.model.Dto.response.BaseResponseDto;

import com.example.demo.model.configEnum.UrlConfigEnum;
import com.example.demo.model.configEnum.UrlEnum;
import lombok.extern.slf4j.Slf4j;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Map;

@Component
@Slf4j
public class BenLaiBaseClient {

    @Autowired
    PartnerConfig config = new PartnerConfig();
    private static Logger logger = Logger.getLogger(BenLaiBaseClient.class);

    protected <T> BaseResponseDto<T> get(String action, Map<String, Object> params, Class<T> var4) {
        String result = this.methodGet(action, params);
        BaseResponseDto<T> resultDto = null;
        if (result != null) {
            resultDto = JSON.parseObject(result, new TypeReference<BaseResponseDto<T>>(var4) {
            });
            logger.info("请求结果:" + result);
        } else {
            logger.error("请求结果为空");
        }
        return resultDto;
    }

    protected <T> BaseResponseDto<T> post(String action, Object params, Class<T> var4) {
        String result = this.methodPost(action, params);
        BaseResponseDto<T> resultDto = null;
        if (result != null) {
            resultDto = JSON.parseObject(result, new TypeReference<BaseResponseDto<T>>(var4) {
            });
            logger.info("请求结果:" + result);
        } else {
            logger.error("请求结果为空");
        }
        return resultDto;

    }


    public String methodGet(String action, Map<String, Object> params) {
        HttpURLConnection conn = null;
        BufferedReader rd = null;
        StringBuilder sb = new StringBuilder();
        String line = null;
        String response = null;
        String url = null;
        StringBuilder getData = new StringBuilder();
        try {
            if (params != null) {
                for (Map.Entry<String, Object> param : params.entrySet()) {
                    if (getData.length() != 0) getData.append('&');
                    getData.append(param.getKey());
                    getData.append('=');
                    getData.append(URLEncoder.encode((String) param.getValue(), "UTF-8"));
                }
            }
            url = UrlEnum.DOMAIN.getUrl() + action + "?" + getData.toString();
            log.info("接口调用url为=={}", url);
            conn = (HttpURLConnection) new URL(url).openConnection();
            conn.setRequestMethod(UrlConfigEnum.METHODGET.getValue());
            conn.setRequestProperty("Content-Type", "application/json;charset=" + UrlConfigEnum.ENCODEING_UTF8.getValue()); // 设置发送数据的格式
            conn.setDoInput(true);
            conn.setReadTimeout(UrlConfigEnum.CONNECTTIME.getVal());
            conn.setConnectTimeout(UrlConfigEnum.CONNECTTIME.getVal());
            conn.setRequestProperty("Authorization", "Bearer " + TokenClient.getToken()
            );
            conn.setUseCaches(false);
            conn.connect();
            rd = new BufferedReader(new InputStreamReader(conn.getInputStream(), UrlConfigEnum.ENCODEING_UTF8.getValue()));
            while ((line = rd.readLine()) != null) {
                sb.append(line);
            }
            response = sb.toString();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rd != null) {
                    rd.close();
                }
                if (conn != null) {
                    conn.disconnect();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return response;
    }


    public String methodPost(String action, Object params) {
        Reader in = null;
        try {
            URL url = new URL(UrlEnum.DOMAIN.getUrl() + action);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod(UrlConfigEnum.METHODPOST.getValue());
            conn.setRequestProperty("Content-Type", "application/json;charset=" + UrlConfigEnum.ENCODEING_UTF8.getValue()); // 设置发送数据的格式
            conn.setRequestProperty("scope", "all");
            conn.setRequestProperty("Authorization", "Bearer " + TokenClient.getToken());
            conn.setReadTimeout(UrlConfigEnum.CONNECTTIME.getVal());
            conn.setConnectTimeout(UrlConfigEnum.CONNECTTIME.getVal());
            conn.setDoOutput(true);
            conn.getOutputStream().write(JSON.toJSONString(params).getBytes());
            in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder sb = new StringBuilder();
            for (int c; (c = in.read()) >= 0; )
                sb.append((char) c);
            String response = sb.toString();
            System.out.println(response);
            System.out.println(response);
            return response;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } finally {
            try {
                if (in != null) {
                    in.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }

}

package com.example.demo.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.time.LocalDateTime;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * 商品图片表
 *
 * @author generator@Wangzhiwen
 * @since 2021-02-01
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("sku_img")
public class SkuImgDO implements Serializable {


    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 商品id
     */
    private String skuId;

    /**
     * 是否首图
     */
    private String isPrimary;

    /**
     * 排序
     */
    private Integer sort;

    /**
     * 本来图片链接
     */
    private String benlaiImg;

    /**
     * 云书图片链接
     */
    private String yunshuImg;

    private LocalDateTime deleteTime;

    private LocalDateTime updateTime;

    private LocalDateTime createTime;


}

package com.example.demo.model.Dto.response.product;

import com.example.demo.model.Dto.response.ErrorResponseDto;

import java.util.List;

public class UpdownstatusResult extends ErrorResponseDto {

    private List<PoductupdownstatusDto> details;

    public List<PoductupdownstatusDto> getDetails() {
        return details;
    }

    public void setDetails(List<PoductupdownstatusDto> details) {
        this.details = details;
    }
}

package com.example.demo.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;

import java.time.LocalDateTime;
import java.io.Serializable;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * 商品详情表
 *
 * @author generator@Wangzhiwen
 * @since 2021-02-02
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("sku_detail")
public class SkuDetailDO implements Serializable {


    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 商品id
     */
    private String skuId;

    /**
     * 昵称
     */
    private String nickName;

    /**
     * 规格
     */
    private String model;

    /**
     * 尺寸
     */
    private String size;

    /**
     * 保质期
     */
    private String productionDate;

    /**
     * 存储方式
     */
    private String storage;

    private LocalDateTime createTime;

    private LocalDateTime updateTime;


}

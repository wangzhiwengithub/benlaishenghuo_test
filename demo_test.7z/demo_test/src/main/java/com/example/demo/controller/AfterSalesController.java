package com.example.demo.controller;

import com.example.demo.model.Dto.request.aftersale.CancelInfoDto;
import com.example.demo.model.Dto.request.aftersale.CreateInfoDto;
import com.example.demo.model.Dto.response.aftersale.*;
import com.example.demo.model.Dto.response.logistics.DoLogListResultDto;
import com.example.demo.service.AfterSaleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("open/afterSale")
public class AfterSalesController {
    @Autowired
    private AfterSaleService afterSaleService;
    @RequestMapping(value = "/create",method = RequestMethod.POST)
    @ResponseBody
    public    CreateResultDto create(CreateInfoDto info){
        return  afterSaleService.create(info);
    }


    @RequestMapping(value = "/available",method = RequestMethod.GET)
    @ResponseBody
    public  AvailableResultDto available(String doID){
        return  afterSaleService.available(doID);
    }

    @RequestMapping(value = "/list",method = RequestMethod.GET)
    @ResponseBody
    public  GetListResultDto list(String doID){
        return  afterSaleService.list(doID);
    }
    @RequestMapping(value = "/get",method = RequestMethod.GET)
    @ResponseBody
    public  GetRMAResultDto get(String rmaID){
        return  afterSaleService.get(rmaID);
    }

    @RequestMapping(value = "/cancel",method = RequestMethod.POST)
    @ResponseBody
    public   CancelResultDto cancel(CancelInfoDto info){
        return  afterSaleService.cancel(info);
    }


}

package com.example.demo.model.Dto.response.logistics;

public class LogisticsDetailResponse {
    private String logisticsID ;
    private String logisticsDescription ;
    private String logisticsTime ;

    public String getLogisticsID() {
        return logisticsID;
    }

    public void setLogisticsID(String logisticsID) {
        this.logisticsID = logisticsID;
    }

    public String getLogisticsDescription() {
        return logisticsDescription;
    }

    public void setLogisticsDescription(String logisticsDescription) {
        this.logisticsDescription = logisticsDescription;
    }

    public String getLogisticsTime() {
        return logisticsTime;
    }

    public void setLogisticsTime(String logisticsTime) {
        this.logisticsTime = logisticsTime;
    }
}

package com.example.demo.model.Dto.response.product;

public class ProductDeliveryAreaModel {
    /// <summary>省级编号</summary>
    private int provinceId ;
    /// <summary>省级名称</summary>
    private String provinceName ;
    /// <summary>市级编号</summary>
    private int cityId ;
    /// <summary>市级名称</summary>
    private String cityName ;
    /// <summary>区县编号</summary>
    private int districtId ;
    /// <summary>区县名称</summary>
    private String districtName ;

    public int getProvinceId() {
        return provinceId;
    }

    public void setProvinceId(int provinceId) {
        this.provinceId = provinceId;
    }

    public String getProvinceName() {
        return provinceName;
    }

    public void setProvinceName(String provinceName) {
        this.provinceName = provinceName;
    }

    public int getCityId() {
        return cityId;
    }

    public void setCityId(int cityId) {
        this.cityId = cityId;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public int getDistrictId() {
        return districtId;
    }

    public void setDistrictId(int districtId) {
        this.districtId = districtId;
    }

    public String getDistrictName() {
        return districtName;
    }

    public void setDistrictName(String districtName) {
        this.districtName = districtName;
    }
}

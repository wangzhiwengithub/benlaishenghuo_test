package com.example.demo.controller;

import com.example.demo.model.Dto.request.aftersale.CreateInfoDto;
import com.example.demo.model.Dto.response.Area.AreaResultDto;
import com.example.demo.model.Dto.response.aftersale.CreateResultDto;
import com.example.demo.service.AfterSaleService;
import com.example.demo.service.AreaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.resource.HttpResource;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Controller
@RequestMapping("open/area")
public class AreaController {

    @Autowired
    private AreaService areaService;

    @RequestMapping(value = "/get", method = RequestMethod.POST)
    @ResponseBody
    public AreaResultDto get(HttpServletResponse response) {
        response.addHeader("Access-Control-Allow-Origin", "*");//解决跨域问题的方法之一，但有弊端?
        return areaService.get();
    }
}

package com.example.demo.entity;

import java.math.BigDecimal;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;

import java.time.LocalDateTime;

import com.baomidou.mybatisplus.annotation.TableField;

import java.io.Serializable;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * 商品表
 *
 * @author generator@Wangzhiwen
 * @since 2021-02-05
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("sku")
public class SkuDO implements Serializable {


    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 单品id
     */
    private String skuId;

    /**
     * 商品名称
     */
    private String productName;

    /**
     * 类别id
     */
    private Integer categoryId;

    /**
     * 大类id
     */
    private Integer c1Id;

    /**
     * 大类名称
     */
    private String c1Name;

    /**
     * 中类id
     */
    private Integer c2Id;

    /**
     * 中类名称
     */
    private String c2Name;

    /**
     * 小类id
     */
    private Integer c3Id;

    /**
     * 小类名称
     */
    private String c3Name;

    /**
     * 供应商
     */
    private String vendor;

    /**
     * 协议含税单价，保留两位小数
     */
    private BigDecimal price;

    /**
     * 市场价
     */
    @TableField("market_Price")
    private BigDecimal marketPrice;

    /**
     * 协议税率
     */
    private Integer tax;

    /**
     * 库存
     */
    private Integer stock;

    /**
     * 产地
     */
    private String productionArea;

    /**
     * 0为初始；1为明细
     */
    private Integer status;

    /**
     * 上下架状态，1上架；0下架
     */
    private Integer online;

    private LocalDateTime createTime;

    private LocalDateTime updateTime;

    private LocalDateTime deleteTime;


}

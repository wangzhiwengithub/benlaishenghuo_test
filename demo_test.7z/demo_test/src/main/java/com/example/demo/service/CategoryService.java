package com.example.demo.service;

import com.example.demo.model.Dto.response.BaseResponseDto;
import com.example.demo.model.Dto.response.category.CategoryResult;

public interface CategoryService {

    CategoryResult categoryOne();

    CategoryResult categoryTwo();

    CategoryResult categoryThree();
}

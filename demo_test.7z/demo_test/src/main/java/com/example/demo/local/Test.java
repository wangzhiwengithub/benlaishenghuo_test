package com.example.demo.local;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;

public class Test {
    public static void main(String[] args) {
        JSONArray jsonArray = new JSONArray();
        jsonArray.add("1");
        jsonArray.add("2");
        jsonArray.add("3");
        jsonArray.add("4");
        String s = JSON.toJSONString(jsonArray);
        System.out.println(s);
    }
}

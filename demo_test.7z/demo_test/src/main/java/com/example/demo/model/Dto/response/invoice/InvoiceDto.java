package com.example.demo.model.Dto.response.invoice;

import java.math.BigDecimal;

public class InvoiceDto {
    /// <summary>
    /// 发票号码
    /// </summary>
    private String invoiceNumber ;
    /// <summary>
    /// 发票代码
    /// </summary>
    private String invoiceCode ;
    /// <summary>
    /// 发票日期 格式 'yyyyMMdd'
    /// </summary>
    private String invoiceDate ;
    /// <summary>
    /// 发票金额 保留2位小数
    /// </summary>
    private BigDecimal invoiceAmount ;
    /// <summary>
    /// 发票税率
    /// </summary>
    private int invoiceTax ;

    public String getInvoiceNumber() {
        return invoiceNumber;
    }

    public void setInvoiceNumber(String invoiceNumber) {
        this.invoiceNumber = invoiceNumber;
    }

    public String getInvoiceCode() {
        return invoiceCode;
    }

    public void setInvoiceCode(String invoiceCode) {
        this.invoiceCode = invoiceCode;
    }

    public String getInvoiceDate() {
        return invoiceDate;
    }

    public void setInvoiceDate(String invoiceDate) {
        this.invoiceDate = invoiceDate;
    }

    public BigDecimal getInvoiceAmount() {
        return invoiceAmount;
    }

    public void setInvoiceAmount(BigDecimal invoiceAmount) {
        this.invoiceAmount = invoiceAmount;
    }

    public int getInvoiceTax() {
        return invoiceTax;
    }

    public void setInvoiceTax(int invoiceTax) {
        this.invoiceTax = invoiceTax;
    }
}

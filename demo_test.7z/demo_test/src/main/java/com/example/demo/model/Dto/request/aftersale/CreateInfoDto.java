package com.example.demo.model.Dto.request.aftersale;

import java.util.List;

public class CreateInfoDto {
    private String doid ;

    private String type ;

    private String description ;

    private List<String> descriptionimg ;

    private String contact ;

    private String phone ;

    private String telephone ;

    private String province ;

    private String city ;

    private String county ;

    private String receiveaddress ;

    private List<CreateProductInfo> productlist ;

    public String getDoid() {
        return doid;
    }

    public void setDoid(String doid) {
        this.doid = doid;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<String> getDescriptionimg() {
        return descriptionimg;
    }

    public void setDescriptionimg(List<String> descriptionimg) {
        this.descriptionimg = descriptionimg;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getReceiveaddress() {
        return receiveaddress;
    }

    public void setReceiveaddress(String receiveaddress) {
        this.receiveaddress = receiveaddress;
    }

    public List<CreateProductInfo> getProductlist() {
        return productlist;
    }

    public void setProductlist(List<CreateProductInfo> productlist) {
        this.productlist = productlist;
    }
}

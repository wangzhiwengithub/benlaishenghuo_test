package com.example.demo.controller;

import com.example.demo.model.Dto.request.order.CancelInfoDto;
import com.example.demo.model.Dto.request.order.ConfirmInfoDto;
import com.example.demo.model.Dto.request.order.CreateInfoDto;
import com.example.demo.model.Dto.request.order.QueryOrderDto;
import com.example.demo.model.Dto.response.order.*;
import com.example.demo.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("open/order")
public class OrderController {


@Autowired
private OrderService orderService;


    @RequestMapping(value = "/create",produces = MediaType.APPLICATION_JSON_UTF8_VALUE )
    @ResponseBody
    public CreateResultDto create( @RequestBody CreateInfoDto request) {
        return orderService.createOrder(request);
    }

    @RequestMapping(value = "/confirm",produces = MediaType.APPLICATION_JSON_UTF8_VALUE )
    @ResponseBody
    public ConfirmResultDto confirm(@RequestBody ConfirmInfoDto request) {
        return orderService.confirmOrder(request);
    }

    @RequestMapping(value = "/cancel",produces = MediaType.APPLICATION_JSON_UTF8_VALUE )
    @ResponseBody
    public CancelResultDto cancel(@RequestBody CancelInfoDto request) {
        return orderService.cancelOrder(request);
    }

    @RequestMapping(value = "/query",method = RequestMethod.GET)
    @ResponseBody
    public QueryResultDto query(@RequestBody  QueryOrderDto request) {
        return orderService.queryOrder(request);

    }

    @RequestMapping(value = "/querydo",method = RequestMethod.GET)
    @ResponseBody
    public QueryDoResultDto querydo(  String doId) {
        return orderService.queryDo(doId);

    }

}

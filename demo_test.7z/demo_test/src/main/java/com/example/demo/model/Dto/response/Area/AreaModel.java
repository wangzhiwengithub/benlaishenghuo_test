package com.example.demo.model.Dto.response.Area;

import java.util.List;

public class AreaModel {
    private int id;
    private String name;
    private int parentId;
    private List<AreaModel> subList;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getParentId() {
        return parentId;
    }

    public void setParentId(int parentId) {
        this.parentId = parentId;
    }

    public List<AreaModel> getSubList() {
        return subList;
    }

    public void setSubList(List<AreaModel> subList) {
        this.subList = subList;
    }
}

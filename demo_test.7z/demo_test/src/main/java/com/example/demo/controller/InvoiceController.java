package com.example.demo.controller;

import com.example.demo.model.Dto.request.invoice.InvoiceCreateInfo;
import com.example.demo.model.Dto.response.Area.AreaResultDto;
import com.example.demo.model.Dto.response.invoice.InvoiceCreateResult;
import com.example.demo.model.Dto.response.invoice.InvoiceGetResult;
import com.example.demo.service.AreaService;
import com.example.demo.service.InvoiceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("open/invoice")
public class InvoiceController {

    @Autowired
    private InvoiceService invoiceService;

    @RequestMapping(value = "/create", method = RequestMethod.POST)
    @ResponseBody
    public  InvoiceCreateResult create(InvoiceCreateInfo info) {
        return invoiceService.create(info);
    }

    @RequestMapping(value = "/get", method = RequestMethod.GET)
    @ResponseBody
    public  InvoiceGetResult get(String markID, String invoiceId) {
        return invoiceService.get(markID,invoiceId);
    }


}

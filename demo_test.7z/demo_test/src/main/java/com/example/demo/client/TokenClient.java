package com.example.demo.client;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.example.demo.config.PartnerConfig;
import com.example.demo.model.Dto.response.BaseResponseDto;
import com.example.demo.model.Dto.response.TokenResponseResultDto;
import com.example.demo.model.configEnum.UrlEnum;
import com.example.demo.util.Util;
import org.springframework.stereotype.Component;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;
@Component
public class TokenClient {

    private static PartnerConfig config=new PartnerConfig();
    //token值
    private  static  String token=null;
    //token的注册时间
    private  static Date getTokenTime=null;
    //接口中refreshtoken值
    private  static  String refreshToken=null;


    public static String   getToken(){
        //没token获取token
        if (token == null || token.isEmpty()) {
            setToken();
        } else {
            //判断时间是否需要refreshToken
            double time = Util.calTime(getTokenTime, new Date());
            //refreshToken,并把标识重置
            if(refreshToken==null&&(token!=null || ! token.isEmpty())){
                setToken();
            }
            if (time > 1  && refreshToken != null) {
                setRefreshToken();
            }
        }
        return  token;
    }
    private static void setToken(){
        BaseResponseDto<TokenResponseResultDto> tokenResponse = token();
        //获取token接口返回成功
        if (tokenResponse.getCode() >= 0) {
            token = tokenResponse.getValue().getAccessToken();
            refreshToken = tokenResponse.getValue().getRefreshToken();
            getTokenTime = Util.formartTime(tokenResponse.getValue().getIssued());
        }
    }
    private static void setRefreshToken(){
        BaseResponseDto<TokenResponseResultDto> refreshToken = refreshToken();
        if(refreshToken.getCode()>=0){
            token = refreshToken.getValue().getAccessToken();
            getTokenTime = Util.formartTime(refreshToken.getValue().getIssued());
            refreshToken = null;
        }
    }


    private  static    BaseResponseDto<TokenResponseResultDto>   token(){
        Map<String,Object> params  = new LinkedHashMap<>();
        params.put("grant_type", "client_credentials");
        return   postGetToken(params,TokenResponseResultDto.class);
    }

    private static BaseResponseDto<TokenResponseResultDto>  refreshToken(){
        Map<String,Object> params  = new LinkedHashMap<>();
        params.put("grant_type", "refresh_token");
        params.put("refresh_token", refreshToken);
        return   postGetToken(params,TokenResponseResultDto.class);
    }



    private  static <T> BaseResponseDto<T> postGetToken(Map<String, Object> params, Class<T> var4) {
        Reader in=null;
        try {
            URL url = new URL(UrlEnum.DOMAIN.getUrl() + UrlEnum.TOKEN.getUrl());
            StringBuilder postData = new StringBuilder();
            for (Map.Entry<String, Object> param : params.entrySet()) {
                if (postData.length() != 0) postData.append('&');
                postData.append(URLEncoder.encode(param.getKey(), "UTF-8"));
                postData.append('=');
                postData.append(URLEncoder.encode(String.valueOf(param.getValue()), "UTF-8"));
            }
            byte[] postDataBytes = postData.toString().getBytes("UTF-8");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            conn.setRequestProperty("Content-Length", String.valueOf(postDataBytes.length));
//            conn.setRequestProperty("scope", "all");
            conn.setRequestProperty("scope", "environment");
            conn.setRequestProperty("Authorization", config.getAuthorization());
            conn.setDoOutput(true);
            conn.getOutputStream().write(postDataBytes);
            in = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (int c; (c = in.read()) >= 0; )
                sb.append((char) c);
            String response = sb.toString();
            System.out.println(response);
            BaseResponseDto<T> temp = (BaseResponseDto<T>) JSON.parseObject(response, new TypeReference<BaseResponseDto<T>>(var4) {
            });
            System.out.println(temp);
            return temp;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }finally {
            try {
                if (in != null) {
                    in.close();
                }
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
    }

}

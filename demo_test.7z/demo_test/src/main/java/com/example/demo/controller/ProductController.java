package com.example.demo.controller;


import com.example.demo.model.Dto.response.invoice.InventoryResult;
import com.example.demo.model.Dto.response.product.*;
import com.example.demo.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("open/product")
public class ProductController {

    @Autowired
    private ProductService productService;


    @RequestMapping(value = "/ids", method = RequestMethod.GET)
    @ResponseBody
    public IdsResult ids(@RequestParam(name = "category_id") Integer categoryId) {
        return productService.ids(categoryId);
    }

    @RequestMapping(value = "/item", method = RequestMethod.GET)
    @ResponseBody
    public ProductResult item(String productIds) {
        return productService.item(productIds);
    }

    @RequestMapping(value = "/images", method = RequestMethod.GET)
    @ResponseBody
    public ProductImageResult images(String productId) {
        return productService.images(productId);
    }

    @RequestMapping(value = "/details", method = RequestMethod.GET)
    @ResponseBody
    public ProductDetailResult details(String productId) {
        return productService.details(productId);
    }

    @RequestMapping(value = "/inventory", method = RequestMethod.GET)
    @ResponseBody
    public InventoryResult inventory(String productIds) {
        return productService.inventory(productIds);
    }

    @RequestMapping(value = "/updownStatus", method = RequestMethod.GET)
    @ResponseBody
    public UpdownstatusResult updownStatus(String productIds) {
        return productService.updownstatus(productIds);
    }

    @RequestMapping(value = "/checkArea", method = RequestMethod.GET)
    @ResponseBody
    public CheckareaResult checkArea(String productIds) {
//        return productService.checkarea(productIds);
        return null;
    }

    @RequestMapping(value = "/getPrice", method = RequestMethod.GET)
    @ResponseBody
    public GetPriceResult getPrice(String productIds) {
        return productService.getprice(productIds);
    }
}

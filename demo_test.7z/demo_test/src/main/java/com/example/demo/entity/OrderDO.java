package com.example.demo.entity;

import java.math.BigDecimal;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.time.LocalDateTime;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * 订单表
 *
 * @author generator@Wangzhiwen
 * @since 2021-02-07
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("order")
public class OrderDO implements Serializable {


    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 自有订单号
     */
    private String orderNo;

    /**
     * 外部预订单号
     */
    private String outTradeNo;

    /**
     * 外部订单号
     */
    private String outOrderId;

    private BigDecimal totalPrice;

    private Integer totalCount;

    private LocalDateTime createTime;

    private LocalDateTime deleteTime;

    /**
     * 订单过期时间
     */
    private LocalDateTime expiredTime;

    /**
     * 订单生成时间
     */
    private LocalDateTime placedTime;

    private LocalDateTime updateTime;

    private Integer status;

    @TableField("isClose")
    private Integer isClose;

    /**
     * 订单交货单IDs
     */
    private String doIds;

    /**
     * 订单详情ids
     */
    private String orderItemIds;


}

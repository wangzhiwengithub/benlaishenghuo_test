package com.example.demo.model.Dto.response.order;

import com.alibaba.fastjson.annotation.JSONField;
import com.example.demo.model.Dto.response.ErrorResponseDto;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

public class QueryResultDto extends ErrorResponseDto {
    @JSONField(name = "out_trade_no")
    private String outTradeNo;
    @JSONField(name = "order_id")
    private String orderId;
    @JSONField(name = "receive_contact")
    private String receiveContact;
    @JSONField(name = "receive_phone")
    private String receivePhone;

    private String province;
    private String city;
    private String county;
    @JSONField(name = "receive_address")
    private String receiveAddress;
    @JSONField(name = "order_price")
    private BigDecimal orderPrice;
    @JSONField(name = "order_status")
    private String orderStatus;
    @JSONField(name = "order_status_remark")
    private String orderStatusRemark;
    @JSONField(format="yyyy-MM-dd HH:mm:ss",name="create_date")
    private Date createDate;
    @JSONField(name = "shipPrice")
    private BigDecimal shipPrice;
    @JSONField(name = "order_detail")
    private List<OrderDetailDto> orderDetail;
    @JSONField(name = "do_list")
    private  List<String> doList;




    public String getOutTradeNo() {
        return outTradeNo;
    }

    public void setOutTradeNo(String outTradeNo) {
        this.outTradeNo = outTradeNo;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getReceiveContact() {
        return receiveContact;
    }

    public void setReceiveContact(String receiveContact) {
        this.receiveContact = receiveContact;
    }

    public String getReceivePhone() {
        return receivePhone;
    }

    public void setReceivePhone(String receivePhone) {
        this.receivePhone = receivePhone;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getReceiveAddress() {
        return receiveAddress;
    }

    public void setReceiveAddress(String receiveAddress) {
        this.receiveAddress = receiveAddress;
    }

    public BigDecimal getOrderPrice() {
        return orderPrice;
    }

    public void setOrderPrice(BigDecimal orderPrice) {
        this.orderPrice = orderPrice;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    public String getOrderStatusRemark() {
        return orderStatusRemark;
    }

    public void setOrderStatusRemark(String orderStatusRemark) {
        this.orderStatusRemark = orderStatusRemark;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public BigDecimal getShipPrice() {
        return shipPrice;
    }

    public void setShipPrice(BigDecimal shipPrice) {
        this.shipPrice = shipPrice;
    }

    public List<OrderDetailDto> getOrderDetail() {
        return orderDetail;
    }

    public void setOrderDetail(List<OrderDetailDto> orderDetail) {
        this.orderDetail = orderDetail;
    }

    public List<String> getDoList() {
        return doList;
    }

    public void setDoList(List<String> doList) {
        this.doList = doList;
    }
}

package com.example.demo.model.Dto.response.logistics;

import com.example.demo.model.Dto.response.ErrorResponseDto;

import java.math.BigDecimal;

public class FreightResultDto extends ErrorResponseDto {

    private BigDecimal freeAmount ;

    private BigDecimal freight ;

    public BigDecimal getFreeAmount() {
        return freeAmount;
    }

    public void setFreeAmount(BigDecimal freeAmount) {
        this.freeAmount = freeAmount;
    }

    public BigDecimal getFreight() {
        return freight;
    }

    public void setFreight(BigDecimal freight) {
        this.freight = freight;
    }
}

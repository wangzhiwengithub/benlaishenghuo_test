demo-test

-- ----------------------------
-- Table structure for area
-- ----------------------------
CREATE TABLE `area` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL COMMENT '父地区id',
  `area_id` int(11) DEFAULT NULL COMMENT '地区id',
  `area_name` varchar(255) DEFAULT NULL COMMENT '地区名称',
  `create_time` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  `update_time` datetime(3) DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `delete_time` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38283 DEFAULT CHARSET=utf8 COMMENT='地区字典表';

-- ----------------------------
-- Table structure for category
-- ----------------------------
CREATE TABLE `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL COMMENT '父类id',
  `category_id` int(11) DEFAULT NULL COMMENT '类别id',
  `category_name` varchar(255) DEFAULT NULL COMMENT '类比名称',
  `level` int(11) DEFAULT NULL COMMENT '层级',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3831 DEFAULT CHARSET=utf8 COMMENT='类别表';

-- ----------------------------
-- Table structure for do
-- ----------------------------
CREATE TABLE `do` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `out_trade_no` varchar(255) DEFAULT NULL COMMENT '商户订单号 您的订单id',
  `order_id` varchar(255) DEFAULT NULL COMMENT '接单方订单id 本分销平台的订单id',
  `out_time` varchar(255) DEFAULT NULL COMMENT '出库时间 格式“yyyyMMddHHmmss”',
  `do_status` varchar(255) DEFAULT NULL COMMENT '出库单状态',
  `do_status_remark` varchar(255) DEFAULT NULL COMMENT '出库单状态描述',
  `ship_price` decimal(13,2) DEFAULT '0.00' COMMENT '运费',
  `waybill_no` varchar(255) DEFAULT NULL COMMENT '运单号',
  `express_company` varchar(255) DEFAULT NULL COMMENT '快递公司名称',
  `create_time` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  `update_time` datetime(3) DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COMMENT='出库表';

-- ----------------------------
-- Table structure for do_item
-- ----------------------------
CREATE TABLE `do_item` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `do_id` int(11) unsigned NOT NULL COMMENT '出库单id',
  `product_id` varchar(255) DEFAULT NULL COMMENT '商品编号',
  `product_name` varchar(255) DEFAULT NULL COMMENT '商品名称',
  `quantity` int(11) unsigned DEFAULT NULL COMMENT '商品数量',
  `create_time` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  `update_time` datetime(3) DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COMMENT='出库详情表';

-- ----------------------------
-- Table structure for order
-- ----------------------------
CREATE TABLE `order` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `order_no` varchar(255) DEFAULT NULL COMMENT '自有订单号',
  `out_trade_no` varchar(255) DEFAULT NULL COMMENT '外部预订单号',
  `out_order_id` varchar(255) DEFAULT NULL COMMENT '外部订单号',
  `total_price` decimal(10,2) DEFAULT '0.00',
  `total_count` int(11) unsigned DEFAULT '0',
  `create_time` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  `delete_time` datetime(3) DEFAULT NULL,
  `expired_time` datetime(3) DEFAULT NULL COMMENT '订单过期时间',
  `placed_time` datetime(3) DEFAULT NULL COMMENT '订单生成时间',
  `update_time` datetime(3) DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `status` tinyint(3) unsigned DEFAULT '1',
  `isClose` tinyint(2) unsigned DEFAULT '0',
  `do_ids` json DEFAULT NULL COMMENT '订单交货单IDs',
  `order_item_ids` json DEFAULT NULL COMMENT '订单详情ids',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=272 DEFAULT CHARSET=utf8mb4 COMMENT='订单表';

-- ----------------------------
-- Table structure for order_item
-- ----------------------------
CREATE TABLE `order_item` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `order_no` varchar(255) DEFAULT NULL COMMENT '自有订单号',
  `product_id` varchar(255) DEFAULT NULL COMMENT '商品编号',
  `product_name` varchar(255) DEFAULT NULL COMMENT '商品名称',
  `quantity` int(11) unsigned DEFAULT NULL COMMENT '可售数量',
  `price` decimal(13,2) DEFAULT NULL COMMENT '商品含税单价',
  `create_time` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  `delete_time` datetime(3) DEFAULT NULL,
  `update_time` datetime(3) DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=272 DEFAULT CHARSET=utf8mb4 COMMENT='订单详情表';

-- ----------------------------
-- Table structure for sku
-- ----------------------------
CREATE TABLE `sku` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sku_id` varchar(255) CHARACTER SET big5 NOT NULL COMMENT '单品id',
  `product_name` varchar(100) DEFAULT NULL COMMENT '商品名称',
  `category_id` int(11) DEFAULT NULL COMMENT '类别id',
  `c1_id` int(11) unsigned DEFAULT NULL COMMENT '大类id',
  `c1_name` varchar(255) DEFAULT NULL COMMENT '大类名称',
  `c2_id` int(11) unsigned DEFAULT NULL COMMENT '中类id',
  `c2_name` varchar(255) DEFAULT NULL COMMENT '中类名称',
  `c3_id` int(11) unsigned DEFAULT NULL COMMENT '小类id',
  `c3_name` varchar(255) DEFAULT NULL COMMENT '小类名称',
  `vendor` varchar(255) DEFAULT NULL COMMENT '供应商',
  `price` decimal(13,2) DEFAULT NULL COMMENT '协议含税单价，保留两位小数',
  `market_Price` decimal(13,2) DEFAULT NULL COMMENT '市场价',
  `tax` int(11) DEFAULT NULL COMMENT '协议税率',
  `stock` int(11) DEFAULT NULL COMMENT '库存',
  `production_area` varchar(255) DEFAULT NULL COMMENT '产地',
  `status` tinyint(4) DEFAULT '0' COMMENT '0为初始；1为明细',
  `online` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '上下架状态，1上架；0下架',
  `create_time` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  `update_time` datetime(3) DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `delete_time` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4622 DEFAULT CHARSET=utf8 COMMENT='商品表';

-- ----------------------------
-- Table structure for sku_area
-- ----------------------------
CREATE TABLE `sku_area` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sku_id` varchar(255) NOT NULL COMMENT '商品id',
  `province_id` int(11) unsigned NOT NULL COMMENT '省份id',
  `city_id` int(11) NOT NULL COMMENT '城市id',
  `district_id` int(11) NOT NULL COMMENT '区域id',
  `create_time` datetime(3) DEFAULT CURRENT_TIMESTAMP(3) COMMENT '创建时间',
  `update_time` datetime(3) DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3) COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=151160 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Table structure for sku_detail
-- ----------------------------
CREATE TABLE `sku_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sku_id` varchar(512) DEFAULT NULL COMMENT '商品id',
  `nick_name` varchar(255) DEFAULT NULL COMMENT '昵称',
  `model` varchar(255) DEFAULT NULL COMMENT '规格',
  `size` varchar(255) DEFAULT NULL COMMENT '尺寸',
  `production_date` varchar(255) DEFAULT NULL COMMENT '保质期',
  `storage` varchar(255) DEFAULT NULL COMMENT '存储方式',
  `create_time` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  `update_time` datetime(3) DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1307 DEFAULT CHARSET=utf8 COMMENT='商品详情表';

-- ----------------------------
-- Table structure for sku_detail_img
-- ----------------------------
CREATE TABLE `sku_detail_img` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sku_detail_id` int(11) DEFAULT NULL COMMENT '商品详情id',
  `type` int(11) DEFAULT NULL COMMENT '详情类型:(1:features;2:buyers;3:proposals;4:stories;5:steps)',
  `index` int(11) unsigned DEFAULT NULL COMMENT '排序从0开始步长为1',
  `content` text COMMENT '描述内容',
  `benlai_detailImg` varchar(255) DEFAULT NULL COMMENT '本来生活商品详情图片路径',
  `yunshu_detailImg` varchar(255) DEFAULT NULL COMMENT '云书网商品详情图片路径',
  `create_time` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  `update_time` datetime(3) DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `delete_time` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2840 DEFAULT CHARSET=utf8 COMMENT='商品详情图片表';

-- ----------------------------
-- Table structure for sku_img
-- ----------------------------
CREATE TABLE `sku_img` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sku_id` varchar(255) DEFAULT NULL COMMENT '商品id',
  `is_primary` varchar(255) DEFAULT NULL COMMENT '是否首图',
  `sort` int(11) unsigned DEFAULT NULL COMMENT '排序',
  `benlai_img` varchar(512) DEFAULT NULL COMMENT '本来图片链接',
  `yunshu_img` varchar(512) DEFAULT NULL COMMENT '云书图片链接',
  `delete_time` datetime(3) DEFAULT NULL,
  `update_time` datetime(3) DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `create_time` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26687 DEFAULT CHARSET=utf8 COMMENT='商品图片表';


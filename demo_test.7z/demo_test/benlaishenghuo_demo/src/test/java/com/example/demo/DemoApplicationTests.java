package com.example.demo;

import com.example.demo.service.AreaService;
import com.example.demo.service.ProductService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class DemoApplicationTests {
    @Autowired
    private ProductService productService;
    @Autowired
    private AreaService areaService;

    @Test
    public void fetchArea() {
        areaService.get();
    }

    /**
     * 获取商品大类
     */
    @Test
    public void fetchCategoryOne() {
        productService.syncCatetoryOne();
    }

    /**
     * 获取商品中类
     */
    @Test
    public void fetchCategoryTwo() {
        productService.syncCatetoryTwo();
    }

    /**
     * 获取商品小类
     */
    @Test
    public void fetchCategoryThree() {
        productService.syncCatetoryThree();
    }

    /**
     * 获取商品标识
     */
    @Test
    public void fetchProductIds() {
        productService.syncProductIds();
    }

    /**
     * 获取商品主要信息
     */
    @Test
    public void fetchProductInfo() {
        productService.syncProductMainInfo();
    }

    /**
     * 获取商品主图
     */
    @Test
    public void fetchProductMainImgs() {
        productService.syncProductMainImages();
    }

    /**
     * 获取商品详情
     */
    @Test
    public void fetchProductDetail() {
        productService.syncProductDetail();
    }

    /**
     * 获取商品上下架状态
     */
    @Test
    public void fetchProductOnlineStatus() {
        productService.syncProductOnlineStatus();
    }

    /**
     * 获取商品的可配送区域
     */
    @Test
    public void fetchProductCanDeliveryArea() {
        productService.syncProductCanDeliverArea();
    }

    /**
     * 获取商品的可销售区域
     */
    @Test
    public void fetchProductCanSaleArea() {
        productService.syncProductCanSaleArea();
    }

    /**
     * 获取商品的价格，分页
     */
    @Test
    public void fetchProductPrices() {
        productService.syncProductPrices();
    }

    /**
     * 获取商品的库存，分页
     */
    @Test
    public void fetchProductStocks() {
        productService.syncProductStocks();
    }
}

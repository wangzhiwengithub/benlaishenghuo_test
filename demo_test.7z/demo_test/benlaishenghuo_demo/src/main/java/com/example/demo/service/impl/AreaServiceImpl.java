package com.example.demo.service.impl;

import com.example.demo.client.AreaClient;
import com.example.demo.entity.AreaDO;
import com.example.demo.mapper.AreaMapper;
import com.example.demo.model.Dto.response.Area.AreaModel;
import com.example.demo.model.Dto.response.Area.AreaResultDto;
import com.example.demo.service.AreaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service("areaService")
public class AreaServiceImpl implements AreaService {
    @Autowired
    private AreaClient areaClient;
    @Autowired
    private AreaMapper areaMapper;

    @Override
    public AreaResultDto get() {
        AreaResultDto value = areaClient.get().getValue();
        List<AreaModel> addrAll = value.getAddrAll();
        for (AreaModel areaModel : addrAll) {
            //外层
            int id = areaModel.getId();
            String name = areaModel.getName();
            int parentId = areaModel.getParentId();
            System.out.println("id: " + id + " name: " + name + " parentId: " + parentId);
            this.saveArea(id, parentId, name);
            List<AreaModel> subList = areaModel.getSubList();
            //中层
            for (AreaModel areaModel1 : subList) {
                int id1 = areaModel1.getId();
                String name1 = areaModel1.getName();
                int parentId1 = areaModel1.getParentId();
                System.out.println("id: " + id1 + " name: " + name1 + " parentId: " + parentId1);
                this.saveArea(id1, parentId1, name1);
                List<AreaModel> subList1 = null;
                try {
                    subList1 = areaModel1.getSubList();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                if (subList1 == null) {
                    continue;
                }
                //内层
                for (AreaModel areaModel2 : subList1) {
                    int id2 = areaModel2.getId();
                    String name2 = areaModel2.getName();
                    int parentId2 = areaModel2.getParentId();
                    System.out.println("id: " + id2 + " name: " + name2 + " parentId: " + parentId2);
                    this.saveArea(id2, parentId2, name2);
                    List<AreaModel> subList2 = areaModel2.getSubList();
                    assert subList2.isEmpty();
                }
            }
        }
        return areaClient.get().getValue();
    }

    private void saveArea(Integer areaId, Integer parentId, String areaName) {
        AreaDO areaDO = new AreaDO();
        areaDO.setAreaId(areaId);
        areaDO.setParentId(parentId);
        areaDO.setAreaName(areaName);
        int insert = this.areaMapper.insert(areaDO);
    }
}

package com.example.demo.controller;

import com.example.demo.model.Dto.request.aftersale.CreateInfoDto;
import com.example.demo.model.Dto.response.Area.AreaResultDto;
import com.example.demo.model.Dto.response.aftersale.CreateResultDto;
import com.example.demo.service.AfterSaleService;
import com.example.demo.service.AreaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("open/area")
public class AreaController {

    @Autowired
    private AreaService areaService;

    @RequestMapping(value = "/get", method = RequestMethod.POST)
    @ResponseBody
    public AreaResultDto get() {
        return areaService.get();
    }
}

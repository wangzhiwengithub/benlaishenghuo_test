package com.example.demo.service.impl;

import com.example.demo.client.TokenClient;
import com.example.demo.model.Dto.request.order.CancelInfoDto;
import com.example.demo.model.Dto.request.order.ConfirmInfoDto;
import com.example.demo.model.Dto.request.order.CreateInfoDto;
import com.example.demo.model.Dto.request.order.QueryOrderDto;
import com.example.demo.model.Dto.response.BaseResponseDto;

import com.example.demo.model.Dto.response.order.*;

import com.example.demo.service.OrderService;
import com.example.demo.client.OrderClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("orderService")
public class OrderServiceImpl implements OrderService {
    @Autowired
    private OrderClient order;
    @Autowired
    private TokenClient token;

    @Override
    public CreateResultDto createOrder(CreateInfoDto info) {

        BaseResponseDto<CreateResultDto> result= order.createOrder(info);
        return  result.getValue();

    }

    @Override
    public ConfirmResultDto confirmOrder(ConfirmInfoDto info) {
        BaseResponseDto< ConfirmResultDto> result= order.confirmOrder(info);
        return result.getValue();
    }

    @Override
    public QueryDoResultDto queryDo(String doID) {
        BaseResponseDto< QueryDoResultDto> result= order.queryDo(doID);
        return result.getValue();
    }

    @Override
    public QueryResultDto queryOrder(QueryOrderDto info) {

        BaseResponseDto< QueryResultDto> result= order.queryOrder(info);
       return  result.getValue();
    }

    @Override
    public CancelResultDto cancelOrder(CancelInfoDto info) {
        BaseResponseDto< CancelResultDto> result= order.cancelOrder(info);
        return  result.getValue();
    }


}


package com.example.demo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 商品表 Mapper 接口
 * </p>
 *
 * @author generator@Wangzhiwen
 * @since 2021-01-29
 */
public interface SkuMapper extends BaseMapper<SkuDO> {

}
